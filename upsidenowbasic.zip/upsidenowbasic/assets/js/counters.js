/**
 * Counts .counter-number elements up from 0 to their data-target value the
 * first time they scroll into view. An optional data-suffix (e.g. "+" or "%")
 * is appended when the count finishes.
 *
 * Used by: patterns/Counters.php.
 */
( function () {
	var counters = document.querySelectorAll( '.counter-number' );
	if ( ! counters.length || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}

	var duration = 2000; // ms

	function animateCounter( el ) {
		var target = parseInt( el.dataset.target, 10 ) || 0;
		var suffix = el.dataset.suffix || '';
		var start = performance.now();

		function step( now ) {
			var progress = Math.min( ( now - start ) / duration, 1 );
			// Ease-out cubic.
			var eased = 1 - Math.pow( 1 - progress, 3 );
			el.textContent = Math.floor( eased * target ).toLocaleString() + ( progress === 1 ? suffix : '' );
			if ( progress < 1 ) {
				requestAnimationFrame( step );
			}
		}

		requestAnimationFrame( step );
	}

	var observer = new IntersectionObserver( function ( entries ) {
		entries.forEach( function ( entry ) {
			if ( entry.isIntersecting ) {
				animateCounter( entry.target );
				observer.unobserve( entry.target ); // Count up once.
			}
		} );
	}, { threshold: 0.3 } );

	counters.forEach( function ( el ) {
		observer.observe( el );
	} );
} )();
