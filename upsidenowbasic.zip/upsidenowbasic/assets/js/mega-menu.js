/**
 * Desktop mega menu (hover panels) plus the mobile hamburger menu and its
 * accordion sections.
 *
 * Used by: patterns/DemoHeader2.php.
 */
( function () {
	var menubar = document.querySelector( '.menubar' );
	if ( menubar ) {
		var dropdowns = menubar.querySelectorAll( '.dropdown' );

		menubar.addEventListener( 'mouseleave', function () {
			menubar.classList.remove( 'open' );
			delete menubar.dataset.active;
			dropdowns.forEach( function ( d ) {
				d.classList.remove( 'active' );
			} );
		} );

		dropdowns.forEach( function ( d ) {
			d.addEventListener( 'mouseenter', function () {
				menubar.classList.add( 'open' );
				menubar.dataset.active = d.dataset.panel;
				dropdowns.forEach( function ( other ) {
					other.classList.remove( 'active' );
				} );
				d.classList.add( 'active' );
			} );
		} );
	}

	// Mobile hamburger.
	var mobileToggle = document.querySelector( '.mobile-toggle' );
	var mobileNav = document.querySelector( '.mobile-nav' );
	if ( mobileToggle && mobileNav ) {
		mobileToggle.addEventListener( 'click', function () {
			var isOpen = mobileNav.classList.toggle( 'open' );
			mobileToggle.classList.toggle( 'open', isOpen );
			mobileToggle.setAttribute( 'aria-expanded', isOpen );
			mobileNav.setAttribute( 'aria-hidden', ! isOpen );
		} );
	}

	// Mobile accordion: one section open at a time.
	document.querySelectorAll( '.mobile-item-header' ).forEach( function ( header ) {
		header.addEventListener( 'click', function () {
			var item = header.parentElement;
			var wasOpen = item.classList.contains( 'open' );
			document.querySelectorAll( '.mobile-item' ).forEach( function ( i ) {
				i.classList.remove( 'open' );
			} );
			if ( ! wasOpen ) {
				item.classList.add( 'open' );
			}
		} );
	} );
} )();
