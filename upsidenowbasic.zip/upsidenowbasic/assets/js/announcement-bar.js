/**
 * Dismissible announcement bar with a utility bar that stays aligned below it
 * and hides once the page scrolls past 100px.
 *
 * The utility bar aligns to the top of #menuBar when the page has one
 * (patterns/DemoHeader2.php), otherwise to the bottom of #announcementBar
 * (patterns/DemoHeader.php).
 */
( function () {
	var util = document.getElementById( 'utilityBar' );
	var ann = document.getElementById( 'announcementBar' );
	var closeButton = document.getElementById( 'announcementClose' );
	if ( ! util || ! ann ) {
		return;
	}

	var menuBar = document.getElementById( 'menuBar' );
	var ticking = false;
	var rafId = null;

	// Keep the utility bar aligned with the bar above it.
	function syncTop() {
		var top = menuBar
			? menuBar.getBoundingClientRect().top
			: ann.getBoundingClientRect().bottom;
		util.style.top = top + 'px';
	}

	// Re-align every frame while the dismiss transition runs.
	function animateDismiss() {
		syncTop();
		rafId = requestAnimationFrame( animateDismiss );
	}

	function stopAnimate() {
		if ( rafId ) {
			cancelAnimationFrame( rafId );
			rafId = null;
		}
		syncTop(); // Final snap.
	}

	// Hide the utility bar once the page scrolls past 100px.
	window.addEventListener( 'scroll', function () {
		if ( ! ticking ) {
			requestAnimationFrame( function () {
				util.classList.toggle( 'hidden', window.scrollY >= 100 );
				ticking = false;
			} );
			ticking = true;
		}
	}, { passive: true } );

	if ( closeButton ) {
		closeButton.addEventListener( 'click', function () {
			ann.classList.add( 'dismissed' );
			animateDismiss();
			// Stop the animation loop once the CSS transition ends.
			ann.addEventListener( 'transitionend', stopAnimate, { once: true } );
		} );
	}

	syncTop();
	window.addEventListener( 'load', syncTop );
	window.addEventListener( 'resize', syncTop );
} )();
