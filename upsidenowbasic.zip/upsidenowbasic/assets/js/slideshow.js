/**
 * Simple auto-advancing slideshow: shows one .mySlides element at a time,
 * marks the matching .dot as active, and advances every 4 seconds.
 *
 * Used by: patterns/HeroBannerDemo.php.
 */
( function () {
	var slides = document.getElementsByClassName( 'mySlides' );
	var dots = document.getElementsByClassName( 'dot' );
	if ( ! slides.length ) {
		return;
	}

	var slideIndex = 0;

	function showSlides() {
		var i;
		for ( i = 0; i < slides.length; i++ ) {
			slides[ i ].style.display = 'none';
		}
		slideIndex++;
		if ( slideIndex > slides.length ) {
			slideIndex = 1;
		}
		for ( i = 0; i < dots.length; i++ ) {
			dots[ i ].classList.remove( 'active' );
		}
		slides[ slideIndex - 1 ].style.display = 'block';
		if ( dots[ slideIndex - 1 ] ) {
			dots[ slideIndex - 1 ].classList.add( 'active' );
		}
		setTimeout( showSlides, 4000 );
	}

	showSlides();
} )();
