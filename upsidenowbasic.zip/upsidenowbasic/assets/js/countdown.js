/**
 * Countdown to the next recurring session: an anchor date, then every 21 days
 * (every third Tuesday) after it. Fills #cd-w, #cd-d, #cd-h, #cd-m and #cd-s.
 *
 * Used by: parts/training-banner.html.
 */
( function () {
	var ids = [ 'cd-w', 'cd-d', 'cd-h', 'cd-m', 'cd-s' ];
	var els = ids.map( function ( id ) {
		return document.getElementById( id );
	} );
	if ( els.some( function ( el ) { return ! el; } ) ) {
		return;
	}

	function nextSessionDate() {
		var now = new Date();
		var d = new Date( 2024, 0, 2, 9, 0, 0 );
		while ( d <= now ) {
			d.setDate( d.getDate() + 21 );
		}
		return d;
	}

	var target = nextSessionDate();

	function pad( n ) {
		return String( n ).padStart( 2, '0' );
	}

	function updateCountdown() {
		var diff = Math.max( 0, target - new Date() );
		var totalDays = Math.floor( diff / 86400000 );
		diff -= totalDays * 86400000;
		var h = Math.floor( diff / 3600000 );
		diff -= h * 3600000;
		var m = Math.floor( diff / 60000 );
		diff -= m * 60000;
		var s = Math.floor( diff / 1000 );

		els[ 0 ].textContent = Math.floor( totalDays / 7 );
		els[ 1 ].textContent = totalDays % 7;
		els[ 2 ].textContent = pad( h );
		els[ 3 ].textContent = pad( m );
		els[ 4 ].textContent = pad( s );
	}

	updateCountdown();
	setInterval( updateCountdown, 1000 );
} )();
