/**
 * Scroll reveal fallback for browsers without CSS scroll-driven animations
 * (animation-timeline: view()). Toggles .in-view on .scrollblock and .statbox
 * elements as they enter and leave the viewport, so the CSS transition plays
 * forward on entry and in reverse on exit.
 *
 * Used by: parts/Parallax3.html, patterns/Parallax.php, patterns/Parallax2.php,
 * patterns/ScrollBox.php.
 */
( function () {
	if ( window.CSS && CSS.supports( 'animation-timeline: view()' ) ) {
		return;
	}
	if ( ! ( 'IntersectionObserver' in window ) ) {
		return;
	}

	var elements = document.querySelectorAll( '.scrollblock, .statbox' );
	if ( ! elements.length ) {
		return;
	}

	// Threshold 0: fires as soon as any pixel enters or exits the viewport.
	var observer = new IntersectionObserver( function ( entries ) {
		entries.forEach( function ( entry ) {
			entry.target.classList.toggle( 'in-view', entry.isIntersecting );
		} );
	}, { threshold: 0 } );

	elements.forEach( function ( el ) {
		observer.observe( el );
	} );
} )();
