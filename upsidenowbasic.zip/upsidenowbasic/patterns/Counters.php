<?php
/**
 * Title: Counters
 * Slug: upsidenowbasic/counters
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} --> <div class="wp-block-group"><!-- wp:columns {"align":"wide"} --> <div class="wp-block-columns alignwide"><!-- wp:column --> <div class="wp-block-column"><!-- wp:html --><div class="counters">       <div class="counter">         <div class="counter-number" data-target="350" data-suffix="+"><?php esc_html_e( '350+', 'upsidenowbasic' ); ?></div>         <div class="counter-label"><?php esc_html_e( 'Projects Completed', 'upsidenowbasic' ); ?></div>       </div>       <div class="counter">         <div class="counter-number" data-target="1200" data-suffix="+"><?php esc_html_e( '1,200+', 'upsidenowbasic' ); ?></div>         <div class="counter-label"><?php esc_html_e( 'Coffees Consumed', 'upsidenowbasic' ); ?></div>       </div>       <div class="counter">         <div class="counter-number" data-target="98" data-suffix="%"><?php esc_html_e( '98%', 'upsidenowbasic' ); ?></div>         <div class="counter-label"><?php esc_html_e( 'Happy Customers', 'upsidenowbasic' ); ?></div>       </div>       <div class="counter">         <div class="counter-number" data-target="50000" data-suffix="+"><?php esc_html_e( '50,000+', 'upsidenowbasic' ); ?></div>         <div class="counter-label"><?php esc_html_e( 'Lines of Code', 'upsidenowbasic' ); ?></div>       </div>     </div> <!-- /wp:html --></div> <!-- /wp:column --></div> <!-- /wp:columns --></div> <!-- /wp:group -->
