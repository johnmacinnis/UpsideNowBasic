<?php
/**
 * Title: Services banner
 * Slug: upsidenowbasic/part-services-banner
 * Inserter: no
 *
 * Content for parts/services-banner.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:group {"className":"services-hero-banner","style":{"css":"    padding:88px 0 64px; background:#0B1B33; color:#fff;\n    background-image:\n      radial-gradient(700px 320px at 85% -10%, rgba(34,211,238,.18), transparent 60%),\n      radial-gradient(600px 300px at 10% 0%, rgba(41,82,227,.28), transparent 60%);"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group services-hero-banner has-custom-css"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:html -->
<style>
.eyebrow{font-family:var(--wp--preset--font-family--work-sans); font-size:15px; font-weight:600; letter-spacing:.14em; text-transform:uppercase; color:#22D3EE;}

/* Sweeping light beam — matches the training-hero-banner treatment for a consistent site feel */
.services-hero-banner{ position:relative; overflow:hidden; isolation:isolate; }
.services-hero-banner::before{
  content:"";
  position:absolute;
  top:-50%;
  left:-30%;
  width:35%;
  height:200%;
    background:linear-gradient(
      100deg,
      transparent 0%,
      #ffffff00 30%,
      #ffffff06 48%,
      #ffffff11 50%,
      #ffffff06 52%,
      #ffffff00 70%,
      transparent 100%
    );
  transform:rotate(8deg);
  animation:servicesBannerBeamSweep 6s ease-in-out infinite;
  pointer-events:none;
  z-index:-1;
}
@keyframes servicesBannerBeamSweep{
  0%{ left:-30%; }
  45%{ left:120%; }
  100%{ left:120%; }
}
@media (prefers-reduced-motion: reduce){
  .services-hero-banner::before{ animation:none; display:none; }
}
</style>
  <div class="eyebrow"><?php esc_html_e( 'Lorem ipsum dolor sit amet consectetur adipiscing elit', 'upsidenowbasic' ); ?></div>
<!-- /wp:html -->

<!-- wp:spacer {"height":"28px"} -->
<div style="height:28px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"70%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:70%"><!-- wp:heading {"level":1,"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"xx-large"} -->
<h1 class="wp-block-heading alignwide has-white-color has-text-color has-link-color has-xx-large-font-size"><?php esc_html_e( 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut.', 'upsidenowbasic' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"14px"} -->
<div style="height:14px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"typography":{"fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|accent-5"}}}},"textColor":"accent-5","fontSize":"medium"} -->
<p class="has-accent-5-color has-text-color has-link-color has-medium-font-size" style="font-weight:600"><?php esc_html_e( 'Enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"22px"} -->
<div style="height:22px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-steel"}}}},"textColor":"light-steel","fontSize":"large"} -->
<p class="has-light-steel-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur lorem ipsum dolor.', 'upsidenowbasic' ); ?> </p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-steel"}}}},"textColor":"light-steel","fontSize":"large"} -->
<p class="has-light-steel-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"30%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:30%"><!-- wp:html -->
<style>
   .spinbox { position: relative; top: 0; left: 0; }
   .ring { position: relative; top: 0; animation:wee-spin-services 20s infinite linear; }
   .middle { position: absolute; top: 0; left: 0; }
   @keyframes wee-spin-services { 0%{transform:rotate(0deg)} 100%{transform:rotate(359deg)} }
</style>
<div class="spinbox">
    <img class="ring" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ring_blank.webp" style="width:100%">
    <img class="middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/middle_blank.webp" style="width:100%">
</div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"44px"} -->
<div style="height:44px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:html -->
<style>
  .hero-badges{display:flex; gap:10px; justify-content:flex-start; flex-wrap:wrap; margin-bottom:28px;}
  .hero-cta-row{display:flex; gap:14px; justify-content:flex-start; flex-wrap:wrap;}

  .badge{display:inline-flex; align-items:center; gap:6px; font-family:var(--wp--preset--font-family--work-sans); font-size:12px; font-weight:600; letter-spacing:.04em; padding:6px 12px; border-radius:99px;}
  .badge-cyan{background:rgba(34,211,238,.14); color:#8FE9F7; border:1px solid rgba(34,211,238,.35);}
  .badge-success{background:rgba(18,183,106,.14); color:#5FE0A6; border:1px solid rgba(18,183,106,.4);}

  .btn{font-family:var(--wp--preset--font-family--work-sans); font-weight:600; font-size:15px; border-radius:8px; padding:14px 26px; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; text-decoration:none;}
  .btn-primary{background:#2952E3; color:#fff; box-shadow:0 6px 16px rgba(41,82,227,.35); transition:transform .15s ease, box-shadow .15s ease;}
  .btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 22px rgba(41,82,227,.45); color:#fff;}
  .btn-outline{background:transparent; border:1.5px solid rgba(255,255,255,.35); color:#fff;}
</style>
<div class="hero-badges">
  <span class="badge badge-cyan"><?php esc_html_e( 'Aliqua ut', 'upsidenowbasic' ); ?></span>
  <span class="badge badge-cyan"><?php esc_html_e( 'Enim ad', 'upsidenowbasic' ); ?></span>
  <span class="badge badge-success"><?php esc_html_e( 'Minim veniam quis', 'upsidenowbasic' ); ?></span>
</div>
<div class="hero-cta-row">
  <a href="#book" class="btn btn-primary"><?php esc_html_e( 'Nostrud exercitation ullamco laboris', 'upsidenowbasic' ); ?></a>
  <a href="#pricing" class="btn btn-outline"><?php esc_html_e( 'Nisi ut', 'upsidenowbasic' ); ?></a>
</div>
<!-- /wp:html -->

<!-- wp:spacer {"height":"64px"} -->
<div style="height:64px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->