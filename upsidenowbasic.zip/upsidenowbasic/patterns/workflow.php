<?php
/**
 * Title: Workflow
 * Slug: upsidenowbasic/workflow
 * Categories: featured
 */
?> 

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide">
<!-- wp:html -->
    <div class="card" style="margin-bottom:44px;">
      <div class="steps-flow">
        <div class="step-node"><div class="step-num"><?php esc_html_e( '1', 'upsidenowbasic' ); ?></div><h5><?php esc_html_e( 'Lorem Ipsum', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Dolor sit amet, consectetur', 'upsidenowbasic' ); ?></p></div>
        <div class="step-node"><div class="step-num"><?php esc_html_e( '2', 'upsidenowbasic' ); ?></div><h5><?php esc_html_e( 'Adipiscing Elit', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Sed do eiusmod tempor', 'upsidenowbasic' ); ?></p></div>
        <div class="step-node"><div class="step-num"><?php esc_html_e( '3', 'upsidenowbasic' ); ?></div><h5><?php esc_html_e( 'Incididunt Labore', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Ut enim ad minim veniam', 'upsidenowbasic' ); ?></p></div>
      </div>
    </div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->