<?php
/**
 * Title: Workflow
 * Slug: upsidenowbasic/workflow
 * Categories: featured
 */
?> 

   <style>
        .card{background:#ffffff; border:0.5px solid #475467; border-radius:14px; padding:28px; box-shadow: #475467;}
        .steps-flow{display:flex; align-items:flex-start; justify-content:space-between; position:relative; padding:10px 0;}
        .steps-flow::before{content:''; position:absolute; top:29px; left:40px; right:40px; height:2px; background:repeating-linear-gradient(90deg, #0B1B33 0 8px, transparent 8px 14px);}
        .step-node{position:relative; flex:1; text-align:center; padding:0 10px;}
        .step-num{width:58px; height:58px; margin:0 auto 14px; border-radius:50%; background: #0B1B33; color: #ffffff; display:flex; align-items:center; justify-content:center; position:relative; z-index:2; box-shadow:0 0 0 3px #12B76A;}
    </style>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide">
<!-- wp:html -->
    <div class="card" style="margin-bottom:44px;">
      <div class="steps-flow">
        <div class="step-node"><div class="step-num">1</div><h5><?php esc_html_e( 'Lorem Ipsum', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Dolor sit amet, consectetur', 'upsidenowbasic' ); ?></p></div>
        <div class="step-node"><div class="step-num">2</div><h5><?php esc_html_e( 'Adipiscing Elit', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Sed do eiusmod tempor', 'upsidenowbasic' ); ?></p></div>
        <div class="step-node"><div class="step-num">3</div><h5><?php esc_html_e( 'Incididunt Labore', 'upsidenowbasic' ); ?></h5><p><?php esc_html_e( 'Ut enim ad minim veniam', 'upsidenowbasic' ); ?></p></div>
      </div>
    </div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->