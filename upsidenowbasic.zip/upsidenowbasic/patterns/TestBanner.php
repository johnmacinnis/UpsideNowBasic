<?php
/**
 * Title: Test Banner
 * Slug: upsidenowbasic/test-banner
 * Categories: featured
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"right":"0px","left":"0px","top":"0px","bottom":"0px"},"margin":{"top":"0px","bottom":"0px"},"blockGap":"0px"},"css":"width; 100%"},"backgroundColor":"accent-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-css has-accent-2-background-color has-background" style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:spacer {"height":"42px","width":"0px","style":{"layout":[]}} -->
<div style="height:42px;width:0px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --><!-- wp:group {"style":{"spacing":{"padding":{"right":"0px","left":"0px","top":"0px","bottom":"0px"},"margin":{"top":"0px","bottom":"0px"},"blockGap":"0px"},"css":"width; 100%"},"backgroundColor":"accent-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-css has-accent-2-background-color has-background" style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:spacer {"height":"42px","width":"0px","style":{"layout":[]}} -->
<div style="height:42px;width:0px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-ffd-300"}}}},"textColor":"custom-ffd-300","fontSize":"x-large"} -->
<h2 class="wp-block-heading has-custom-ffd-300-color has-text-color has-link-color has-x-large-font-size"><?php esc_html_e( 'Messaging for Your Business', 'upsidenowbasic' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-4"}}}},"textColor":"accent-4","fontSize":"large"} -->
<h3 class="wp-block-heading has-accent-4-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Communicate Your Core Value Proposition Clearly, Convincingly, and Consistently', 'upsidenowbasic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<p class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( "A strong idea told authentically can often do more than a multi-million-dollar media buy. Say what you mean in clear, concise, honest language. If you're promoting a small business with a limited budget, here is a language playbook.", 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<li class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( 'Start with a sharp, clear concept. Choose the single message or emotion you want people to feel.', 'upsidenowbasic' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<li class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( 'Talk like a human. Honesty, authenticity and clarity beat buzzwords and meaningless catch phrases every time.', 'upsidenowbasic' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"6%"} -->
<div class="wp-block-column" style="flex-basis:6%"></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:html -->
<style>    .spinbox {         position: relative;         top: 0;         left: 0;         width: 75%;     }     .ring {         position: relative;         top: 0;         left: 0;         animation:wee-spin 20s infinite linear     }       .middle {         position: absolute;         top: 0;         left: 0;     } @keyframes wee-spin {     0%{transform:rotate(0deg)}     100%{transform:rotate(359deg)}} </style>  <div class="spinbox">     <img class="middle" src="/wp-content/themes/upsidenowbasic/assets/images/middle6.webp" alt="">     <img class="ring" src="/wp-content/themes/upsidenowbasic/assets/images/ring6.webp" alt="">     <img class="middle" src="/wp-content/themes/upsidenowbasic/assets/images/GBM_.webp" alt="">    </div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"42px","width":"0px","style":{"layout":[]}} -->
<div style="height:42px;width:0px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-ffd-300"}}}},"textColor":"custom-ffd-300","fontSize":"x-large"} -->
<h2 class="wp-block-heading has-custom-ffd-300-color has-text-color has-link-color has-x-large-font-size"><?php esc_html_e( 'Messaging for Your Business', 'upsidenowbasic' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-4"}}}},"textColor":"accent-4","fontSize":"large"} -->
<h3 class="wp-block-heading has-accent-4-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Communicate Your Core Value Proposition Clearly, Convincingly, and Consistently', 'upsidenowbasic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<p class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( "A strong idea told authentically can often do more than a multi-million-dollar media buy. Say what you mean in clear, concise, honest language. If you're promoting a small business with a limited budget, here is a language playbook.", 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<li class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( 'Start with a sharp, clear concept. Choose the single message or emotion you want people to feel.', 'upsidenowbasic' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<li class="has-white-color has-text-color has-link-color has-medium-font-size"><?php esc_html_e( 'Talk like a human. Honesty, authenticity and clarity beat buzzwords and meaningless catch phrases every time.', 'upsidenowbasic' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"6%"} -->
<div class="wp-block-column" style="flex-basis:6%"></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:html -->
<style>    .spinbox {         position: relative;         top: 0;         left: 0;         width: 75%;     }     .ring {         position: relative;         top: 0;         left: 0;         animation:wee-spin 20s infinite linear     }       .middle {         position: absolute;         top: 0;         left: 0;     } @keyframes wee-spin {     0%{transform:rotate(0deg)}     100%{transform:rotate(359deg)}} </style>  <div class="spinbox">     <img class="middle" src="/wp-content/themes/upsidenowbasic/assets/images/middle6.webp" alt="">     <img class="ring" src="/wp-content/themes/upsidenowbasic/assets/images/ring6.webp" alt="">     <img class="middle" src="/wp-content/themes/upsidenowbasic/assets/images/GBM_.webp" alt="">    </div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"42px","width":"0px","style":{"layout":[]}} -->
<div style="height:42px;width:0px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->