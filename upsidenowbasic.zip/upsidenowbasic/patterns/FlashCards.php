<?php
/**
 * Title: Flash Cards
 * Slug: upsidenowbasic/flash-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"100%"} -->
		<div class="wp-block-column" style="flex-basis:100%">

			<!-- wp:html -->

			<div class="flash-can flash-can-dark">

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Minum Aliquiae Sit, Occab Iunt Scrotum', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Ucilic to dolupta tempore ptatest, ius volorestio officipsam ut fugia volupta temqui dolut od ut ea seque pa velique nis ut velecatiunt. Elecumqui que vent.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: green;">
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '5M+ endpoints', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '12M+ identities', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '1M+ active learners', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Ecea Coreribus Dempera Tisimusci', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Aniassi millestrum, a quis mo et voluptatiam es si blabor as comnis quo ipid que sit doluptatur ari odit lant. Sitium quo dolorpos auta nullute strume.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: red;">
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '7M+ volo molorrum', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '16M+ eserum hillas', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '3M+ quibus', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Faceserum Est, Qui At. Ga. Ariorro', 'upsidenowbasic' ); ?> <br></h2>
						<p><?php esc_html_e( 'On rercit voluptatur as ium nobitas perendusam, nectet fugit vero et eum id et id etur? Cum ipsam quide pelit apienih illesci molore corempo rectae quisci delit.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: #ffd300;">
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '15M+ ommolum quo', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '36M+ temporpore', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '3M+ nobitempor autem', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

			</div>
			<!-- /wp:html -->

		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
