<?php
/**
 * Title: Flash Cards
 * Slug: upsidenowbasic/flash-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"100%"} -->
		<div class="wp-block-column" style="flex-basis:100%">

			<!-- wp:html -->
			<style>
				.flash-can {
					display: grid;
					grid-template-columns: 32% 32% 32%;
					gap: 2%;
					padding-top: 21px;
					padding-bottom: 21px;
					width: 100%;
				}

				.flash-can div {
					border: 1px solid #395979;
					border-radius: 12px;
					box-shadow: #395979 10px 5px 20px, #395979 0px -2px 3px 2px inset;
					height: 550px;
					font-size: 21px;
					color: white;
					text-align: center;
					font-family: Arial, Helvetica, sans-serif;
					padding-left: 21px;
					padding-right: 21px;
				}

				.flash-can div:hover {
					animation: highlite .5s normal;
					animation-fill-mode: both;
				}

				.flash-can div:active {
					background-color: #0aed19;
				}

				@keyframes highlite {
					from {
						background-color: none;
					}
					to {
						background-color: #1E3248;
						border: 1px solid #ffd300;
						box-shadow: #777777 10px 5px 20px, #777777 0px -2px 3px 2px inset;
					}
				}

				@media only screen and (max-width: 1250px) {
					.flash-can {
						grid-template-columns: 100%;
						padding-top: 0;
						padding-bottom: 75px;
					}
				}
			</style>

			<div class="flash-can">

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Minum Aliquiae Sit, Occab Iunt Scrotum', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Ucilic to dolupta tempore ptatest, ius volorestio officipsam ut fugia volupta temqui dolut od ut ea seque pa velique nis ut velecatiunt. Elecumqui que vent.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: green;">
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '5M+ endpoints', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '12M+ identities', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted gold;"><?php esc_html_e( '1M+ active learners', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Ecea Coreribus Dempera Tisimusci', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Aniassi millestrum, a quis mo et voluptatiam es si blabor as comnis quo ipid que sit doluptatur ari odit lant. Sitium quo dolorpos auta nullute strume.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: red;">
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '7M+ volo molorrum', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '16M+ eserum hillas', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted green;"><?php esc_html_e( '3M+ quibus', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2 style="color: #B8D0E3;"><?php esc_html_e( 'Faceserum Est, Qui At. Ga. Ariorro', 'upsidenowbasic' ); ?> <br></h2>
						<p><?php esc_html_e( 'On rercit voluptatur as ium nobitas perendusam, nectet fugit vero et eum id et id etur? Cum ipsam quide pelit apienih illesci molore corempo rectae quisci delit.', 'upsidenowbasic' ); ?><br><br></p>
						<span style="color: #ffd300;">
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '15M+ ommolum quo', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '36M+ temporpore', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted red;"><?php esc_html_e( '3M+ nobitempor autem', 'upsidenowbasic' ); ?></p>
						</span>
					</div>
				</a>

			</div>
			<!-- /wp:html -->

		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
