<?php
/**
 * Title: Hero banner
 * Slug: upsidenowbasic/part-hero-banner
 * Inserter: no
 *
 * Content for parts/hero-banner.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Still002.png","dimRatio":90,"overlayColor":"accent-1","isUserOverlayColor":true,"sizeSlug":"full","align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"textColor":"contrast","layout":{"type":"constrained"}} -->
<div class="wp-block-cover aligncenter has-contrast-color has-text-color has-link-color"><img class="wp-block-cover__image-background size-full" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Still002.png" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-accent-1-background-color has-background-dim-90 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:spacer {"height":"54px"} -->
<div style="height:54px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"level":1,"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"xx-large"} -->
<h1 class="wp-block-heading alignwide has-white-color has-text-color has-link-color has-xx-large-font-size"><br><?php esc_html_e( 'Lorem ipsum dolor sit amet', 'upsidenowbasic' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"65%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:65%"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"31px"} -->
<div style="height:31px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e( 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"35%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:35%"><!-- wp:html -->
<style>
   .spinbox {
        position: relative;
        top: 0;
        left: 0;
    }
    .ring {
        position: relative;
        top: 0;
        left: 0;
        animation:wee-spin 20s infinite linear
    }
      .middle {
        position: absolute;
        top: 0;
        left: 0;
    }
@keyframes wee-spin {
    0%{transform:rotate(0deg)}
    100%{transform:rotate(359deg)}}
</style>

<div class="spinbox">
    <img class="ring" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ring_blank.webp">
    <img class="middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/middle_blank.webp">
</div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:html -->
<button id="LearnButton" class="btn btn-primary" style="width:100%; justify-content:center; font-size: x-large;"><?php esc_html_e( 'CTA 1', 'upsidenowbasic' ); ?></button>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:html -->
<button class="btn btn-primary" style="width:100%;justify-content:center; font-size: x-large;"><?php esc_html_e( 'CTA 2', 'upsidenowbasic' ); ?></button>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->