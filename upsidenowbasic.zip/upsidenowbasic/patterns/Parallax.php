<?php
/**
 * Title: Parallax
 * Slug: upsidenowbasic/parallax
 * Categories: featured
 */
?>
<style>
 .parallax {
  background-image: url('/wp-content/themes/upsidenowbasic/assets/images/world-map-kitty.webp');
  height: 720px; 
  justify-content: center;
  align-items: center;
  padding-top: 6px;
    /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
}
 .pg-view {
    width: 100%;
    display: grid;
    grid-template-columns: 100%;
    gap: 1%;
    padding-top: 0px;
    padding-bottom: 250px;
    padding-left: 0%
      }
.statbox {
    height: 200px;
    width: 30%;
    padding: 1vh;
    margin: 1vh; 
    border: 0.5mm solid #395979;
    box-shadow: #eeeeee 10px 5px 20px, #eeeeee 0px -2px 3px 2px inset;
    color:white;
    background-color: #0f1923e7;  
   justify-self: center;
}
@keyframes appear {
        from {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
        }
        to {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }

      /* ── Native: Chrome / Edge / Safari 18+ ── */
      @supports (animation-timeline: view()) {
        .statbox {
          animation: appear linear;
          animation-timeline: view();
          animation-range: entry 0% cover 40%;
        }
      }

      /* ── Fallback: Firefox ── */
    @supports not (animation-timeline: view()) {
        .statbox {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
          transition: opacity 1s linear, clip-path 1s linear;
        }
        .statbox.in-view {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
    }
    
    @media only screen and (max-width: 800px) {
        .statbox {
        width: 80%;
        left: 5%; 
        margin: 6px;
        }
    }
</style>

<div class="parallax">
<div class="pg-view">
    <div class="statbox"><p><span style="font-size: 36px;">59%</span><br><span style="font-size: 21px;">of small businesses are incorporating AI into their marketing strategy.</span></p></div>
    <div class="statbox"><p><span style="font-size: 21px;">California is home to more than<br><span style="font-size: 36px;">4.2 million</span> small businesses<br>— the most of any state</span> </p></div>
    <div class="statbox"><p><span style="font-size: 36px;">28%</span><br><span style="font-size: 21px;">of San Jose's GDP is generated from Information Technology Industries.</span></p></div>
</div>    
</div>

    <script>
      // Only runs in Firefox
      if (!CSS.supports('animation-timeline: view()')) {
        const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              // Entering viewport — play forward
              entry.target.classList.add('in-view');
            } else {
              // Leaving viewport — remove class so transition plays in reverse
              entry.target.classList.remove('in-view');
            }
          });
        // threshold 0: fires as soon as any pixel enters OR exits viewport
        }, { threshold: 0 });

        document.querySelectorAll('.statbox').forEach(el => observer.observe(el));
      }
    </script>