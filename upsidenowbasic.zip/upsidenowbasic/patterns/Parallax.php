<?php
/**
 * Title: Parallax
 * Slug: upsidenowbasic/parallax
 * Categories: featured
 */
?>

<div class="parallax">
<div class="pg-view">
    <div class="statbox"><p><span style="font-size: 36px;"><?php esc_html_e( '59%', 'upsidenowbasic' ); ?></span><br><span style="font-size: 21px;"><?php esc_html_e( 'of small businesses are incorporating AI into their marketing strategy.', 'upsidenowbasic' ); ?></span></p></div>
    <div class="statbox"><p><span style="font-size: 21px;"><?php esc_html_e( 'California is home to more than', 'upsidenowbasic' ); ?><br><span style="font-size: 36px;"><?php esc_html_e( '4.2 million', 'upsidenowbasic' ); ?></span> <?php esc_html_e( 'small businesses', 'upsidenowbasic' ); ?><br><?php esc_html_e( '— the most of any state', 'upsidenowbasic' ); ?></span> </p></div>
    <div class="statbox"><p><span style="font-size: 36px;"><?php esc_html_e( '28%', 'upsidenowbasic' ); ?></span><br><span style="font-size: 21px;"><?php esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'upsidenowbasic' ); ?></span></p></div>
</div>    
</div>
