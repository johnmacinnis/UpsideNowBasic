<?php
/**
 * Title: Parallax
 * Slug: upsidenowbasic/parallax
 * Categories: featured
 */
?>
<style>
 .parallax {
  background-image: url('/wp-content/themes/upsidenowbasic/assets/images/world-map-kitty.webp');
  height: 720px; 
  justify-content: center;
  align-items: center;
  padding-top: 6px;
    /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
}
 .pg-view {
    width: 100%;
    display: grid;
    grid-template-columns: 100%;
    gap: 1%;
    padding-top: 0px;
    padding-bottom: 250px;
    padding-left: 0%
      }
.statbox {
    height: 200px;
    width: 30%;
    padding: 1vh;
    margin: 1vh; 
    border: 0.5mm solid #395979;
    box-shadow: #eeeeee 10px 5px 20px, #eeeeee 0px -2px 3px 2px inset;
    color:white;
    background-color: #0f1923e7;  
   justify-self: center;
}
@keyframes appear {
        from {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
        }
        to {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }

      /* ── Native: Chrome / Edge / Safari 18+ ── */
      @supports (animation-timeline: view()) {
        .statbox {
          animation: appear linear;
          animation-timeline: view();
          animation-range: entry 0% cover 40%;
        }
      }

      /* ── Fallback: Firefox ── */
    @supports not (animation-timeline: view()) {
        .statbox {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
          transition: opacity 1s linear, clip-path 1s linear;
        }
        .statbox.in-view {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
    }
    
    @media only screen and (max-width: 800px) {
        .statbox {
        width: 80%;
        left: 5%; 
        margin: 6px;
        }
    }
</style>

<div class="parallax">
<div class="pg-view">
    <div class="statbox"><p><span style="font-size: 36px;">59%</span><br><span style="font-size: 21px;"><?php esc_html_e( 'of small businesses are incorporating AI into their marketing strategy.', 'upsidenowbasic' ); ?></span></p></div>
    <div class="statbox"><p><span style="font-size: 21px;"><?php esc_html_e( 'California is home to more than', 'upsidenowbasic' ); ?><br><span style="font-size: 36px;"><?php esc_html_e( '4.2 million', 'upsidenowbasic' ); ?></span> <?php esc_html_e( 'small businesses', 'upsidenowbasic' ); ?><br><?php esc_html_e( '— the most of any state', 'upsidenowbasic' ); ?></span> </p></div>
    <div class="statbox"><p><span style="font-size: 36px;">28%</span><br><span style="font-size: 21px;"><?php esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'upsidenowbasic' ); ?></span></p></div>
</div>    
</div>
