<?php
/**
 * Title: Flash Cards
 * Slug: upsidenowbasic/flash-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"100%"} -->
		<div class="wp-block-column" style="flex-basis:100%">

			<!-- wp:html -->
			<style>
				.flash-can {
					display: grid;
					grid-template-columns: 32% 32% 32%;
					gap: 2%;
					padding-top: 21px;
					padding-bottom: 21px;
					width: 100%;
                    background-color: white;
				}

				.flash-can div {
					border: 1px solid #2952E3;
					border-radius: 12px;
					box-shadow: #475467 5px 1px 7px, #475467 0px -2px 3px 2px inset;
					height: 550px;
					font-size: 21px;
					color: #111111;
					text-align: center;
					font-family: Arial, Helvetica, sans-serif;
					padding-left: 21px;
					padding-right: 21px;
				}

				.flash-can div:hover {
					animation: highlite .5s normal;
					animation-fill-mode: both;
				}

				.flash-can div:active {
					background-color: #0aed19;
				}
				  /* ---------- Buttons ---------- */
				.btn{font-family:var(--font-body); font-weight:600; font-size:15px; border-radius:8px; padding:13px 24px; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; text-decoration:none;}
				.btn-primary{background:#2952E3; color:#fff; box-shadow:0 6px 16px rgba(41,82,227,.35); transition:transform .15s ease, box-shadow .15s ease;}
				.btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 22px rgba(41,82,227,.45);background:#000000;}
				.btn-gold{background:var(--gold); color:#1A1200; box-shadow:0 6px 16px rgba(201,154,61,.35);}
				.btn-outline{background:transparent; border:1.5px solid rgba(255,255,255,.35); color:#fff;}
				.btn-outline.on-light{border-color:var(--ink-navy); color:var(--ink-navy);}
				.btn-ghost{background:transparent; color:var(--electric-blue); padding:13px 4px;}

				@keyframes highlite {
					from {
						background-color: none;
					}
					to {
						background-color: #C99A3D77;
					
						box-shadow: #777777 10px 5px 20px, #777777 0px -2px 3px 2px inset;
					}
				}

				@media only screen and (max-width: 1250px) {
					.flash-can {
						grid-template-columns: 100%;
						padding-top: 0;
						padding-bottom: 75px;
					}
				}
			</style>

			<div class="flash-can">

				<a href="https://upside-now.com" target="_blank" style="text-decoration: none;">
					<div>
						<h2>Founding Cohort</h2>
                        <p> First 1-2 cohorts only</p>
						<h2>$297</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;">Live 4-hour Zoom session</p>
							<p style="border-top: 1px dotted black;">Workbook and checklist</p>
							<p style="border-top: 1px dotted black;">Session Recording</p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;">Reserve Seat</button>
					</div>
				</a>

				<a href="https://upside-now.com" target="_blank" style="text-decoration: none;">
					<div>
						<h2>Standard<br></h2>
						<p>Most attendees</p>
                        <h2>$497</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;">Everything in Founding</p>
							<p style="border-top: 1px dotted black;">Private Q&A during class</p>
							<p style="border-top: 1px dotted black;">30 minute follow-up session</p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;">Reserve Seat</button>
					</div>
				</a>

				<a href="https://upside-now.com" target="_blank" style="text-decoration: none;">
					<div>
						<h2>Partner Program</h2>
						<p>Unlimited access + referral program</p>
                        <h2>$997</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;">Subcontract designers</p>
							<p style="border-top: 1px dotted black;">Referral program</p>
							<p style="border-top: 1px dotted black;">Certified Builder</p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;">Become a Partner</button>
					</div>
				</a>

			</div>
			<!-- /wp:html -->

		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
