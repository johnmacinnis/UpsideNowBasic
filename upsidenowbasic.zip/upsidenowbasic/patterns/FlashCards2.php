<?php
/**
 * Title: Pricing Cards
 * Slug: upsidenowbasic/pricing-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"100%"} -->
		<div class="wp-block-column" style="flex-basis:100%">

			<!-- wp:html -->
			<style>
				.flash-can {
					display: grid;
					grid-template-columns: 32% 32% 32%;
					gap: 2%;
					padding-top: 21px;
					padding-bottom: 21px;
					width: 100%;
                    background-color: white;
				}

				.flash-can div {
					border: 1px solid #2952E3;
					border-radius: 12px;
					box-shadow: #475467 5px 1px 7px, #475467 0px -2px 3px 2px inset;
					height: 550px;
					font-size: 21px;
					color: #111111;
					text-align: center;
					font-family: Arial, Helvetica, sans-serif;
					padding-left: 21px;
					padding-right: 21px;
				}

				.flash-can div:hover {
					animation: highlite .5s normal;
					animation-fill-mode: both;
				}

				.flash-can div:active {
					background-color: #0aed19;
				}
				  /* ---------- Buttons ---------- */
				.btn{font-family:var(--font-body); font-weight:600; font-size:15px; border-radius:8px; padding:13px 24px; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; text-decoration:none;}
				.btn-primary{background:#2952E3; color:#fff; box-shadow:0 6px 16px rgba(41,82,227,.35); transition:transform .15s ease, box-shadow .15s ease;}
				.btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 22px rgba(41,82,227,.45);background:#000000;}
				.btn-gold{background:var(--gold); color:#1A1200; box-shadow:0 6px 16px rgba(201,154,61,.35);}
				.btn-outline{background:transparent; border:1.5px solid rgba(255,255,255,.35); color:#fff;}
				.btn-outline.on-light{border-color:var(--ink-navy); color:var(--ink-navy);}
				.btn-ghost{background:transparent; color:var(--electric-blue); padding:13px 4px;}

				@keyframes highlite {
					from {
						background-color: none;
					}
					to {
						background-color: #C99A3D77;
					
						box-shadow: #777777 10px 5px 20px, #777777 0px -2px 3px 2px inset;
					}
				}

				@media only screen and (max-width: 1250px) {
					.flash-can {
						grid-template-columns: 100%;
						padding-top: 0;
						padding-bottom: 75px;
					}
				}
			</style>

			<div class="flash-can">

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Starter', 'upsidenowbasic' ); ?></h2>
                        <p> <?php esc_html_e( 'Limited spots available', 'upsidenowbasic' ); ?></p>
						<h2>$99</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Live 4-hour video session', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Workbook and checklist', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Session Recording', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Reserve Seat', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Standard', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Most attendees', 'upsidenowbasic' ); ?></p>
                        <h2>$199</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Everything in Starter', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Private Q&A during class', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( '30 minute follow-up session', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Reserve Seat', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Partner Program', 'upsidenowbasic' ); ?></h2>
						<p><?php esc_html_e( 'Unlimited access + referral program', 'upsidenowbasic' ); ?></p>
                        <h2>$399</h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Subcontract designers', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Referral program', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Certified Builder', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Become a Partner', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

			</div>
			<!-- /wp:html -->

		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
