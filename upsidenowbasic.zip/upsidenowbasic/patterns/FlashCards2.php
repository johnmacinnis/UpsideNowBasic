<?php
/**
 * Title: Pricing Cards
 * Slug: upsidenowbasic/pricing-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"100%"} -->
		<div class="wp-block-column" style="flex-basis:100%">

			<!-- wp:html -->

			<div class="flash-can">

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Starter', 'upsidenowbasic' ); ?></h2>
                        <p> <?php esc_html_e( 'Limited spots available', 'upsidenowbasic' ); ?></p>
						<h2><?php esc_html_e( '$99', 'upsidenowbasic' ); ?></h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Live 4-hour video session', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Workbook and checklist', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Session Recording', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Reserve Seat', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Standard', 'upsidenowbasic' ); ?><br></h2>
						<p><?php esc_html_e( 'Most attendees', 'upsidenowbasic' ); ?></p>
                        <h2><?php esc_html_e( '$199', 'upsidenowbasic' ); ?></h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Everything in Starter', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Private Q&A during class', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( '30 minute follow-up session', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Reserve Seat', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

				<a href="#" target="_blank" style="text-decoration: none;">
					<div>
						<h2><?php esc_html_e( 'Partner Program', 'upsidenowbasic' ); ?></h2>
						<p><?php esc_html_e( 'Unlimited access + referral program', 'upsidenowbasic' ); ?></p>
                        <h2><?php esc_html_e( '$399', 'upsidenowbasic' ); ?></h2>
						<span style="color: #2952E3;">
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Subcontract designers', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Referral program', 'upsidenowbasic' ); ?></p>
							<p style="border-top: 1px dotted black;"><?php esc_html_e( 'Certified Builder', 'upsidenowbasic' ); ?></p><br>
						</span>
						 <button class="btn btn-primary" style="width:50%; justify-content:center;"><?php esc_html_e( 'Become a Partner', 'upsidenowbasic' ); ?></button>
					</div>
				</a>

			</div>
			<!-- /wp:html -->

		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
