<?php
/**
 * Title: Hero Banner Demo
 * Slug: upsidenowbasic/hero-banner-demo
 * Categories: featured
 */
?>
<!-- wp:cover {"url":"/wp-content/themes/upsidenowbasic/assets/video/Sequence-1s.mp4","id":743,"dimRatio":20,"overlayColor":"contrast","isUserOverlayColor":true,"backgroundType":"video","sizeSlug":"full","align":"center","layout":{"type":"constrained"}} -->
<div class="wp-block-cover aligncenter"><video class="wp-block-cover__video-background intrinsic-ignore" autoplay muted loop playsinline src="/wp-content/themes/upsidenowbasic/assets/video/Sequence-1s.mp4" data-object-fit="cover"></video><span aria-hidden="true" class="wp-block-cover__background has-contrast-background-color has-background-dim-20 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:html -->
<style>

* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;
}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.sl-animate-fading{animation:fading 10s infinite}@keyframes fading{0%{opacity:0}50%{opacity:1}100%{opacity:0}}
.sl-animate-opacity{animation:opac 0.8s}@keyframes opac{from{opacity:0} to{opacity:1}}
.sl-animate-top{position:relative;animation:animatetop 0.4s}@keyframes animatetop{from{top:-300px;opacity:0} to{top:0;opacity:1}}
.sl-animate-left {
    position:relative;
    animation:animateleft 10s infinite
}
@keyframes animateleft {
    from{left:-300px;opacity:0} to{left:0;opacity:1}
}
.sl-animate-right {
    position:relative;
    animation:animateright 5s
}
@keyframes animateright {
   0% {right:-300px;opacity:0;}
   25% {right:0;opacity:1;}
}

.sl-animate-bottom{position:relative;animation:animatebottom 0.4s}@keyframes animatebottom{from{bottom:-300px;opacity:0} to{bottom:0;opacity:1}}
.sl-animate-zoom {animation:animatezoom 0.6s}@keyframes animatezoom{from{transform:scale(0)} to{transform:scale(1)}}
.sl-animate-input{transition:width 0.4s ease-in-out}.sl-animate-input:focus{width:100%!important}

.sl-container {
  max-width: 50%;
  position: relative;
  margin: auto;
}
.sl-container:after,.sl-container:before {
    content:"";
    display:table;
    clear:both;
}
.sl-center {
    text-align:center;
}

/* Caption text */
.text {
  color: #ffffff;
  font-size: 21px;
  padding: 6px 1px 21px 1px;
  bottom: 8px;
  width: 100%;
  text-align: left;
  line-height: 2.0;
}

.header-text {
  color: #ffd300;
  font-size: 36px;
  padding: 48px 1px 6px 1px;
  bottom: 8px;
  width: 100%;
  text-align: left;
  line-height: 3.0;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 0px;
  width: 0px;
  margin: 0 0px;
  background-color: #ffffff00;
  display: none;
}

.active {
  background-color: #ffffff00;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>



<div class="sl-container">

    <div class="mySlides fade">
        <div class="header-text"><?php esc_html_e( 'Want A Free Month of Managed IT Services?', 'upsidenowbasic' ); ?></div>
        <div class="text"><?php esc_html_e( 'Call us today to learn more on how we can provide you with our Elite services for free for one month!', 'upsidenowbasic' ); ?></div>
    </div>

    <div class="mySlides fade">
        <div class="header-text"><?php esc_html_e( 'Hackers Wrecked. Your Enterprise Secured.', 'upsidenowbasic' ); ?></div>
        <div class="text"><?php esc_html_e( 'A purpose-built platform, operated by our industry-proven, 24/7 AI-assisted SOC for continuous threat protection.', 'upsidenowbasic' ); ?></div>
    </div>

    <div class="mySlides fade">
        <div class="header-text"><?php esc_html_e( 'Our Smarter IT Solutions Power Growth', 'upsidenowbasic' ); ?></div>
        <div class="text"><?php esc_html_e( "We don't just manage IT, we transform it by delivering  AI-enabled  IT solutions that reduce downtime, boost productivity, and support growth.", 'upsidenowbasic' ); ?></div>
    </div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

<div class="sl-container sl-center">
    <div class="mySlides sl-animate-left">
        <h1><?php esc_html_e( 'The UpsideNowBasic Theme for WordPress', 'upsidenowbasic' ); ?></h1>
        <p><?php esc_html_e( 'Jump-start your website development process.', 'upsidenowbasic' ); ?></p>
    </div>
    <div class="mySlides sl-animate-left">
        <h1><?php esc_html_e( 'The UpsideNowBasic Theme for WordPress', 'upsidenowbasic' ); ?></h1>
        <p><?php esc_html_e( 'Jump-start your website development process.', 'upsidenowbasic' ); ?></p>
    </div>
</div>


<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 4000); // Change image every x/1000 seconds
}
</script>
<!-- /wp:html -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline","style":{"border":{"width":"1px"}},"borderColor":"base"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-border-color has-base-border-color wp-element-button" style="border-width:1px"><?php esc_html_e( 'Book a Free Discovery Call', 'upsidenowbasic' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->
