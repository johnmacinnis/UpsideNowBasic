<?php
/**
 * Title: jspin
 * Slug: upsidenowbasic/jspn
 * Categories: featured
 */
?>

<div class="upsn-spinbox">
    <img class="upsn-middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/middle7_blank.webp" width="100%" alt="">
    <img class="upsn-ring" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ring7_blank.webp" width="100%" alt="">
    <img class="upsn-middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/GBM.webp" width="100%" alt="">

</div>