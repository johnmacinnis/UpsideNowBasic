<?php
/**
 * Title: jspin
 * Slug: upsidenowbasic/jspn
 * Categories: featured
 */
?>
<style>
   .upsn-spinbox {
        position: relative;
        top: 0;
        left: 0;
        width: 75%;
    }
    .upsn-ring {
        position: relative;
        top: 0;
        left: 0;
        animation:wee-spin 20s infinite linear
    }
      .upsn-middle {
        position: absolute;
        top: 0;
        left: 0;
    }
@keyframes wee-spin {
    0%{transform:rotate(0deg)}
    100%{transform:rotate(359deg)}}
</style>

<div class="upsn-spinbox">
    <img class="upsn-middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/middle7_blank.webp" width="100%" alt="">
    <img class="upsn-ring" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ring7_blank.webp" width="100%" alt="">
    <img class="upsn-middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/GBM.webp" width="100%" alt="">

</div>