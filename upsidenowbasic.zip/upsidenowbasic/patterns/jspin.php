<?php
/**
 * Title: jspin
 * Slug: upsidenowbasic/jspn
 * Categories: featured
 */
?>
<style>
   .upsn-spinbox {
        position: relative;
        top: 0;
        left: 0;
        width: 75%;
    }
    .upsn-ring {
        position: relative;
        top: 0;
        left: 0;
        animation:wee-spin 20s infinite linear
    }
      .upsn-middle {
        position: absolute;
        top: 0;
        left: 0;
    }
@keyframes wee-spin {
    0%{transform:rotate(0deg)}
    100%{transform:rotate(359deg)}}
</style>

<div class="upsn-spinbox">
    <img class="upsn-middle" src="/wp-content/themes/upsidenowbasic/assets/images/middle7.webp" width="100%">
    <img class="upsn-ring" src="/wp-content/themes/upsidenowbasic/assets/images/ring7.webp" width="100%">
    <img class="upsn-middle" src="/wp-content/themes/upsidenowbasic/assets/images/jmac7.webp" width="100%">
  
</div>