<?php
/**
 * Title: Parallax 3
 * Slug: upsidenowbasic/part-parallax-3
 * Inserter: no
 *
 * Content for parts/parallax3.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:html -->
<style>

  .g-view {
      background-image: url("<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/world-map-kitty.webp"); 
  background-attachment: fixed;
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
    width: 100%;
    height: 700px;
    display: grid;
    grid-template-columns: 48% 48%;
    gap: 2%;
    padding-top: 21px;
    padding-bottom: 75px;
color: white;
  }
  .scrollblock {
background-color: #00000099;
     height: 200px;
     border: 0.5mm solid #475467;
     box-shadow: #395979 0px 50px 100px -20px, #395979 0px 30px 60px -30px,#395979 0px -2px 6px 0px inset;
padding-left: 12px;
padding-right: 12px;
     color: white;
     justify-self:center;
font-size: x-large;
      }

      @keyframes appear {
        from {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
        }
        to {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }

      /* ── Native: Chrome / Edge / Safari 18+ ── */
      @supports (animation-timeline: view()) {
        .scrollblock {
          animation: appear linear;
          animation-timeline: view();
          animation-range: entry 0% cover 40%;
        }
      }

      /* ── Fallback: Firefox ── */
      @supports not (animation-timeline: view()) {
        .scrollblock {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
          transition: opacity 0.5s linear, clip-path 0.5s linear;
        }
        .scrollblock.in-view {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }  
   @media only screen and (max-width: 1000px) {
      .g-view {
        grid-template-columns: 100%;
        padding-top: 0;
        padding-bottom: 250px;
      }
    }
  </style>
  

    <div class="g-view">
     <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '43.4%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of all websites on the internet run on WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '61.7%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of websites using a known content management system, use WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '91%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of vulnerabilities reside in plugins.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '84%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of consumers view a business website as more credible than social media alone.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '94%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of first impressions are design-related.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '31%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of U.S. shoppers reported not doing business with a small company because it lacked a website.', 'upsidenowbasic' ); ?></p></div>
    </div>



<!-- /wp:html -->
