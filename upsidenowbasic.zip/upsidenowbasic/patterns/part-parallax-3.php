<?php
/**
 * Title: Parallax 3
 * Slug: upsidenowbasic/part-parallax-3
 * Inserter: no
 *
 * Content for parts/parallax3.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:html -->
  

    <div class="g-view g-view-bg">
     <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '43.4%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of all websites on the internet run on WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '61.7%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of websites using a known content management system, use WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '91%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of vulnerabilities reside in plugins.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '84%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of consumers view a business website as more credible than social media alone.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '94%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of first impressions are design-related.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '31%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of U.S. shoppers reported not doing business with a small company because it lacked a website.', 'upsidenowbasic' ); ?></p></div>
    </div>



<!-- /wp:html -->
