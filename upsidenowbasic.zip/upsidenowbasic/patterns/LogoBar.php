<?php
/**
 * Title: Logo Bar
 * Slug: upsidenowbasic/logo-bar
 * Categories: featured
 */
?>
<style>
  .marquee-wrapper {
    padding-block: 5px;
    margin: 20px auto;
    overflow: hidden;
    /* Fade edges */
    -webkit-mask: linear-gradient(90deg, #0000, #000 10% 90%, #0000);
    mask: linear-gradient(90deg, #0000, #000 10% 90%, #0000);
  }
  .marquee-track {
    display: flex;
    width: max-content;
    animation: marquee-scroll 30s linear infinite;
  }
  .marquee-track--reverse {
    animation-direction: reverse;
  }
  .marquee-wrapper:hover .marquee-track {
    animation-play-state: paused;
  }
  .marquee-track img {
    width: 150px;
    height: auto;
    display: block;
    /*  gap on each side matches the original spacing */
    margin-inline: 30px;
  }
  @keyframes marquee-scroll {
    from { transform: translateX(0); }
    to   { transform: translateX(-50%); }
  }
</style>

<div class="marquee-wrapper">
  <div class="marquee-track" id="track1">
</div>
</div>

<script>
  // Images for each row
  const row1Images = [
    { src: "/wp-content/themes/upsidenowbasic/assets/images/Logo9.webp", alt: "Upside-Now" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/intel.webp", alt: "Intel" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/cisco.webp",  alt: "Cisco" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/truvantis.webp",     alt: "Truvantis" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/SBDC.webp",   alt: "SBDC" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/Score.webp",   alt: "Score" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/UoPhoenix.webp",  alt: "UniversityofPhoenix" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/wordpresswhite.webp",     alt: "WordPress" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/philips.webp",   alt: "Phillips" },
    { src: "/wp-content/themes/upsidenowbasic/assets/images/HID.webp",       alt: "HID" },
  ];

  const row2Images = row1Images; // same set; swap in a different array if needed

  function buildTrack(trackEl, images) {
    // Duplicate the set so the seamless loop works:
    // translateX(-50%) lands exactly back at the start.
    const doubled = [...images, ...images];
    doubled.forEach(({ src, alt }) => {
      const img = document.createElement("img");
      img.src = src;
      img.alt = alt;
      trackEl.appendChild(img);
    });
  }

  buildTrack(document.getElementById("track1"), row1Images);
  buildTrack(document.getElementById("track2"), row2Images);
</script>