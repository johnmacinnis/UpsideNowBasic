<?php
/**
 * Title: Header (main)
 * Slug: upsidenowbasic/part-header-main
 * Inserter: no
 *
 * Content for parts/header-main.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:group {"style":{"position":{"type":""},"spacing":{"padding":{"right":"0px","left":"0px","top":"0px","bottom":"0px"},"blockGap":"0px","margin":{"top":"0px","bottom":"0px"}},"shadow":"var:preset|shadow|natural","background":{"backgroundImage":{"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/world-map-kitty.webp","source":"file","title":"world-map-kitty"},"backgroundSize":"cover","backgroundPosition":"51% 54%"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;box-shadow:var(--wp--preset--shadow--natural)"><!-- wp:columns {"align":"full"} -->
<div class="wp-block-columns alignfull"><!-- wp:column {"verticalAlignment":"center","width":"15%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:15%"><!-- wp:image {"lightbox":{"enabled":false},"width":"244px","height":"auto","aspectRatio":"3.636959732645753","sizeSlug":"large","linkDestination":"custom"} -->
<figure class="wp-block-image size-large is-resized"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/templogo.webp" alt="" style="aspect-ratio:3.636959732645753;width:244px;height:auto"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"55%","style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-right:0;padding-left:0;flex-basis:55%"><!-- wp:navigation {"ref":4,"textColor":"white","overlayTextColor":"custom-color-1","style":{"spacing":{"blockGap":"var:preset|spacing|50"}}} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"30%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:30%"><!-- wp:search {"label":"<?php esc_attr_e( 'Search', 'upsidenowbasic' ); ?>","showLabel":false,"widthUnit":"%","buttonText":"<?php esc_attr_e( 'Search', 'upsidenowbasic' ); ?>","buttonUseIcon":true,"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","borderColor":"white"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->