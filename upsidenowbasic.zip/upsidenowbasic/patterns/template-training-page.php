<?php
/**
 * Title: Training page template
 * Slug: upsidenowbasic/template-training-page
 * Inserter: no
 *
 * Content for templates/training-page.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:html -->
<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'upsidenowbasic' ); ?></a>
<!-- /wp:html -->

<!-- wp:group {"tagName":"header","style":{"position":{"type":"sticky","top":"0px"}},"backgroundColor":"custom-color-1","layout":{"type":"constrained"}} -->
<header class="wp-block-group has-custom-color-1-background-color has-background"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"15%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:15%"><!-- wp:image {"lightbox":{"enabled":false},"aspectRatio":"3.343982830596046","sizeSlug":"large","linkDestination":"custom","align":"left"} -->
<figure class="wp-block-image alignleft size-large"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/templogo.webp" alt="" style="aspect-ratio:3.343982830596046"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"65%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:65%"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-5"}}},"typography":{"textTransform":"none","textAlign":"center"}},"textColor":"accent-5","fontSize":"medium"} -->
<p class="has-text-align-center has-accent-5-color has-text-color has-link-color has-medium-font-size" style="text-transform:none"><?php esc_html_e( 'Lorem ipsum dolor sit amet', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-3"}}},"typography":{"textTransform":"uppercase","textAlign":"center"}},"textColor":"accent-3","fontSize":"medium","fontFamily":"jetbrains-mono"} -->
<p class="has-text-align-center has-accent-3-color has-text-color has-link-color has-jetbrains-mono-font-family has-medium-font-size" style="text-transform:uppercase"><?php esc_html_e( 'Consectetur adipiscing elit sed do', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:html -->
<style data-wp-block-html="css">
.btn{font-family:var(--font-body); font-weight:600; font-size:15px; border-radius:8px; padding:14px 26px; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; text-decoration:none;}
  .btn-primary{background:#2952E3; color:#fff; box-shadow:0 6px 16px rgba(41,82,227,.35); transition:transform .15s ease, box-shadow .15s ease;}
  .btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 22px rgba(41,82,227,.45);} 
  .btn-outline{background:transparent; border:1.5px solid rgba(255,255,255,.35); color:#fff;}
</style>

<a href="#pricing" class="btn btn-primary"><?php esc_html_e( 'Eiusmod tempor', 'upsidenowbasic' ); ?></a>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></header>
<!-- /wp:group -->

<!-- wp:html -->
<main id="main">
<!-- /wp:html -->

<!-- wp:template-part {"slug":"training-banner","theme":"upsidenowbasic","area":"uncategorized"} /-->

<!-- wp:group {"backgroundColor":"light","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-light-background-color has-background"><!-- wp:spacer {"height":"32px"} -->
<div style="height:32px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-4"}}},"typography":{"textTransform":"uppercase","textAlign":"center"}},"textColor":"accent-4","fontSize":"medium","fontFamily":"jetbrains-mono"} -->
<p class="has-text-align-center has-accent-4-color has-text-color has-link-color has-jetbrains-mono-font-family has-medium-font-size" style="text-transform:uppercase"><?php esc_html_e( 'Ut labore', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"32px"} -->
<div style="height:32px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-1"}}},"typography":{"textAlign":"center"}},"textColor":"accent-1","fontSize":"x-large"} -->
<h2 class="wp-block-heading has-text-align-center alignwide has-accent-1-color has-text-color has-link-color has-x-large-font-size"><?php esc_html_e( 'Et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation', 'upsidenowbasic' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"32px"} -->
<div style="height:32px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%"><!-- wp:paragraph {"align":"wide","style":{"typography":{"textAlign":"center"},"elements":{"link":{"color":{"text":"var:preset|color|accent-2"}}}},"textColor":"accent-2","fontSize":"large"} -->
<p class="has-text-align-center alignwide has-accent-2-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur lorem ipsum dolor.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"32px"} -->
<div style="height:32px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"12%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:12%"><!-- wp:html -->
<style data-wp-block-html="css">
.icon-tile{width:64px; height:64px; border-radius:14px; border: 2px solid white; background:#14263F; display:flex; align-items:center; justify-content:center;}
.icon-tile svg{width:28px; height:28px; stroke: #22D3EE; fill:none; stroke-width:1.8;}

</style>

<div class="icon-tile"><svg viewBox="0 0 24 24"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z"></path></svg></div>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"88%"} -->
<div class="wp-block-column" style="flex-basis:88%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-1"}}}},"textColor":"custom-color-1"} -->
<h3 class="wp-block-heading has-custom-color-1-color has-text-color has-link-color"><?php esc_html_e( 'Sit amet consectetur adipiscing', 'upsidenowbasic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-2"}}}},"textColor":"accent-2"} -->
<p class="has-accent-2-color has-text-color has-link-color"><?php esc_html_e( 'Elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"12%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:12%"><!-- wp:html -->
<div class="icon-tile"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.3 2.3L16 9.6"/></svg></div>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"88%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:88%"><!-- wp:spacer {"height":"29px"} -->
<div style="height:29px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-1"}}}},"textColor":"accent-1"} -->
<h3 class="wp-block-heading has-accent-1-color has-text-color has-link-color"><?php esc_html_e( 'Minim veniam quis nostrud exercitation ullamco', 'upsidenowbasic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-2"}}}},"textColor":"accent-2"} -->
<p class="has-accent-2-color has-text-color has-link-color"><?php esc_html_e( 'Laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"12%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:12%"><!-- wp:html -->
<div class="icon-tile"><svg viewBox="0 0 24 24"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/></svg></div>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"88%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:88%"><!-- wp:spacer {"height":"29px"} -->
<div style="height:29px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-color-1"}}}},"textColor":"custom-color-1"} -->
<h3 class="wp-block-heading has-custom-color-1-color has-text-color has-link-color"><?php esc_html_e( 'Reprehenderit in voluptate velit esse cillum', 'upsidenowbasic' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-2"}}}},"textColor":"accent-2"} -->
<p class="has-accent-2-color has-text-color has-link-color"><?php esc_html_e( 'Dolore eu fugiat nulla pariatur lorem ipsum dolor sit amet consectetur adipiscing elit sed do.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"62px"} -->
<div style="height:62px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"curriculum","theme":"upsidenowbasic","area":"uncategorized"} /-->

<!-- wp:template-part {"slug":"flashcards_t","theme":"upsidenowbasic","area":"uncategorized"} /-->

<!-- wp:template-part {"slug":"training-page_bottom","theme":"upsidenowbasic","area":"uncategorized"} /-->

<!-- wp:html -->
</main>
<!-- /wp:html -->

<!-- wp:template-part {"slug":"training-footer","theme":"upsidenowbasic","area":"footer","tagName":"footer"} /-->
