<?php
/**
 * Title: Demo Header 2
 * Slug: upsidenowbasic/demo-header-2
 * Categories: header
 */
?>
<style>
    body{
        background-color: #0f1923;
        /*font-family: Arial, Helvetica, sans-serif;*/
    }
     .headerbar {
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 9998;
    }
 </style>
 
<!--------------------------------------------
------  DISMISSABLE  ANNOUNCEMENT BAR  -------
--------------------------------------------->
 <style>   
    .announcement {
        position: relative;
        width: 100%;
        display: flex;
        align-items: center;
        background-color: black;
        color:white;
        font-size: small;
        overflow: hidden;
        transition: max-height 0.4s ease, opacity 0.4s ease;
        opacity: 1;
    }
    .announcement p{
        font-size: small;
    }
    .announcement.dismissed {
        max-height: 0;
        opacity: 0;
    }
        .announcement-close {
        position: absolute;
        top: 50%;
        right: 12px;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: white;
        font-size: small;
        line-height: 1;
        cursor: pointer;
        opacity: 0.7;
        padding: 4px 8px;
    }
    .announcement-close:hover { opacity: 1; }
  </style>
<!--------------------------------------------
-----  UTILITY BAR, DISOLVES ON SCROLL  ------
--------------------------------------------->
<style>
    .utilitybar {
        position: fixed;
        display: flex;
        font-size: small;
        align-items: center;
        z-index: 9999;
        width: 100%;
        height: 24px;
        color: white;    
        background-color: #1E3248;
        /* top is set dynamically by JS */
        left: 0;
        opacity: 1;
        transition: transform 0.3s ease, opacity 0.3s ease;
        will-change: transform;
    }
    .utilitybar p {
        margin: 0;
        padding: 0;
    }
    .utilitybar.hidden {
        transform: translateY(-300%);
        opacity: 0;
    }
</style>
<!--------------------  ----------------------
---------------   MAIN MENU   ----------------
----------------------  --------------------->
  <style>  
       .dropdown {
        position: relative;
        cursor: pointer;
    }

    .dropdown > p {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 10px 0;
        padding: 0;
        font-size: medium;
        /*font-weight: 600;*/
        letter-spacing: 0.02em;
        color: rgba(255, 255, 255, 0.85);
        transition: color 0.2s;
        user-select: none;
    }

    .dropdown > p::after {
        content: '';
        display: inline-block;
        width: 7px;
        height: 7px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        transform: rotate(45deg) translateY(-2px);
        transition: transform 0.25s ease;
        flex-shrink: 0;
    }

    .dropdown.active > p {
        color: #B8D0E3;
    }

    .dropdown.active > p::after {
        transform: rotate(-135deg) translateY(-2px);
    }
/* menu bar item without extended dropdown box link only*/
     .no-dropdown {
        position: relative;
        cursor: pointer;
    }

    .no-dropdown > p {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 10px 0;
        padding: 0;
        font-size: medium;
        /*font-weight: 600;*/
        letter-spacing: 0.02em;
        color: rgba(255, 255, 255, 0.85);
        transition: color 0.2s;
        user-select: none;
    }
  .no-dropdown > p:hover {
        color: #ffd300;
    }
  .no-dropdown > p:after {
        color: rgba(255, 255, 255, 0.85);
    }
    .menubar {
        display: grid;
        grid-template-columns: 20% 13% 13% 13% 13% 14% 14%;
        grid-template-rows: 84px auto;
        /*gap: 2%;*/
        width: 100%;
        height: 84px;

        background-image: linear-gradient(to right, rgb(40, 70, 95, 0.95), rgb(15, 25, 35,0.95));
        color: white;
        transition: height 0.3s ease;
        overflow: hidden;
        align-items: end;
    }

    .menubar.open {
        height: 600px;
        border-bottom: 2px solid #4eb5f7;
    }

    /* Expanded content panel — spans full menubar width */
    .dropdown-panel {
        display: none;
        grid-column: 1 / -1;
        padding: 24px 0 32px 0;
        border-top: 1px solid rgba(255, 211, 0, 0.25);
        margin-top: 8px;
    }

    .menubar[data-active="services"] .dropdown-panel[data-panel="services"],
    .menubar[data-active="support"]  .dropdown-panel[data-panel="support"],
    .menubar[data-active="book"]     .dropdown-panel[data-panel="book"],
    .menubar[data-active="company"]     .dropdown-panel[data-panel="company"] {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 24px;
    }

    .panel-col img {
        width: 100%;
        border-radius: 4px;
        display: block;
        margin-bottom: 10px;
        object-fit: cover;
    }

    .panel-col {
        padding: 0 16px;
        border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .panel-col:last-child {
        border-right: none;
    }

    .panel-col h4 {
        font-size: large;
        font-weight: 300;
       
  
        color: #B8D0E3;
        margin: 0 0 12px 0;
    }

    .panel-col p {
        font-size: medium;
        line-height: 1.5;
        color: rgba(255, 255, 255, 0.72);
        margin: 0 0 14px 0;
    }

    .panel-col a {
        display: block;
        font-size: medium;
        color: rgba(255, 255, 255, 0.55);
        text-decoration: none;
        margin-bottom: 8px;
        transition: color 0.15s;
    }

    .panel-col a h4:hover {
        color: #ffd300;
    }
  
    /* ── Hamburger button ── */
    .mobile-toggle {
        display: none;
        flex-direction: column;
        justify-content: center;
        gap: 5px;
        background: none;
        border: none;
        cursor: pointer;
        padding: 8px 16px 8px 8px;
        align-self: center;
        justify-self: end;
    }

    .mobile-toggle span {
        display: block;
        width: 24px;
        height: 2px;
        background: white;
        border-radius: 2px;
        transition: transform 0.25s ease, opacity 0.25s ease;
    }

    .mobile-toggle.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
    .mobile-toggle.open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
    .mobile-toggle.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

    /* ── Mobile nav drawer ── */
    .mobile-nav {
        display: none;
        background: #0f1923;
        border-top: 2px solid #ffd300;
    }

    .mobile-nav.open { display: block; }

    .mobile-item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        color: rgba(255, 255, 255, 0.85);
        font-size: medium;
        font-weight: 600;
        cursor: pointer;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        user-select: none;
        transition: color 0.2s;
    }

    .mobile-item-header .m-arrow {
        width: 8px;
        height: 8px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        transform: rotate(45deg) translateY(-2px);
        transition: transform 0.25s ease;
        flex-shrink: 0;
    }

    .mobile-item.open .mobile-item-header { color: #ffd300; }
    .mobile-item.open .mobile-item-header .m-arrow { transform: rotate(-135deg) translateY(-2px); }

    .mobile-item-panel {
        display: none;
        padding: 16px 20px 20px;
        background: rgba(0, 0, 0, 0.3);
        columns: 2;
        column-gap: 24px;
    }

    .mobile-item.open .mobile-item-panel { display: block; }

    .mobile-item-panel h4 {
        font-size: small;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #ffd300;
        margin: 0 0 8px;
        break-after: avoid;
    }

    .mobile-item-panel a {
        display: block;
        font-size: small;
        color: rgba(255, 255, 255, 0.6);
        text-decoration: none;
        padding: 4px 0;
        transition: color 0.15s;
    }

    .mobile-item-panel a:hover { color: #ffd300; }

    .mobile-item-panel .m-group { break-inside: avoid; margin-bottom: 16px; }

    /* ── Breakpoint ── */
    @media (max-width: 850px) {
        .menubar {
            grid-template-columns: 1fr auto;
            grid-template-rows: 60px;
            height: 60px !important;
            border-bottom: none !important;
        }

        .menubar > .dropdown,
        .menubar > .dropdown-panel {
            display: none;
        }

        .mobile-toggle { display: flex; }
        .announcement p{
            font-size: x-small;
        }
    }
</style>    


 <div class="headerbar">
    <div class="announcement" id="announcementBar">
        <button class="announcement-close" id="announcementClose" aria-label="Dismiss">✕</button>
        <p>&nbsp; &nbsp;Free Assessment &amp; Consultation for San Jose SMBs - Limited Spots Available.  <a href="https://upside-now.com" style="color:#ffd300;">Claim yours-&gt;</a></p>
    </div>
<div class="utilitybar" id="utilityBar" style="top: 48px;">
    <p>&nbsp; &nbsp; Need help setting up your website? Give me a call. &nbsp; &nbsp;<img src="/wp-content/themes/upsidenowbasic/assets/images/phone-1.webp" alt="Book a Call" style="width:16px;"> <a href="tel:+14085550100" style="text-decoration:none;">(408) 479-4274</a>
                &nbsp;|&nbsp; San Jose, CA</p>
</div>
    
<div class="menubar" id="menuBar">
    <div><img src="/wp-content/themes/upsidenowbasic/assets/images/templogo.webp" alt="" style="height: 30px"></div>
    <button class="mobile-toggle" aria-label="Toggle menu" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>
    
    <div class="dropdown" data-panel="services">
        <p>Services</p>
    </div>

    <div class="dropdown" data-panel="support">
        <p>Industries</p>
    </div>

    <div class="dropdown" data-panel="book">
        <p>Insights</p>
    </div>

    <div class="dropdown" data-panel="company">
        <p>Company</p>
    </div>

    <a href="/"><div class="no-dropdown"><p>Client Support</p></div></a>
    <a href="/"><div class="no-dropdown"><p>Book a Free Discovery Call</p></div></a>

    <!-- Services panel -->
    <div class="dropdown-panel" data-panel="services">
        <div class="panel-col">
            <a href="/"><h4>Complete IT Management</h4></a>
            <p>Let us handle IT so you can focus on growing your business.</p>
            <a href="/"><h4>Co-Managed IT Services</h4></a>
            <p>Full-stack development from simple integrations to complex web applications and APIs.</p>
            <a href="/"><h4>Managed End-User Support</h4></a>
            <p>Get multichannel 24/7/365 expert end-user support.</p>
        </div>
        <div class="panel-col">
           <a href="/"><h4>Cybersecurity Services</h4></a>
            <p>Protect, detect, and respond—Dataprise keeps your business secure.</p>
            <a href="/"><h4>Disaster Recovery</h4></a>
            <p>Maximize uptime with with industry-leading DRaaS.</p>
            <a href="/"><h4>Incident Response</h4></a>
            <p>Swiftly mitigate cyber threats and restore security</p>
        </div>
        <div class="panel-col">
            <a href="/"><h4>Cloud &amp; Infrastructure</h4></a>
            <p>Improve efficiency, productivity and outcomes with cloud.</p>
            <a href="/"><h4>Mobility Management</h4></a>
            <p>Ensure all mobile devices, everywhere, are secure.</p>
            <a href="/"><h4>IT Consulting</h4></a>
            <p>Gain a competitive edge with strategic IT solutions.</p>            
         </div>
        <div class="panel-col">
            <a href="/"><h4>AI-driven Cyber-hygene Program</h4></a>
            <p>Strategic AI guidance to align with your business goals and budget. What could go wrong?</p>
        </div>
        <div class="panel-col">
            <img src="/wp-content/themes/upsidenowbasic/assets/images/shake.webp" alt="Our Services" style="width:150px;">
            <p>Award-winning design and development delivered on time, every time.</p>
        </div>
    </div>

    <!-- Industries panel -->
    <div class="dropdown-panel" data-panel="support">
        <div class="panel-col">
            <a href="/"><h4>Industries Overview</h4></a><h4><a href="/"></a>
<p>IT for businesses of all sizes, in any industry.</p>
<a href="/"><h4>Banking</h4></a></h4><h4><a href="/"></a>
<p>Empower institution growth with custom IT solutions.</p>
<a href="/"><h4>Financial Services</h4></a></h4><h4><a href="/"></a>
<p>Ensure your firm is always in compliance. </p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4>Healthcare</h4></a><h4><a href="/"></a>
<p>Improve patient care and staff morale.</p>
<a href="/"><h4>Legal</h4></a></h4><h4><a href="/"></a>
<p>Deal with pressing legal matters, not IT.</p>
<a href="/"><h4>Media &amp; Entertainment</h4></a></h4><h4><a href="/"></a>
<p>Keep up with the evolving digital landscape. </p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4>Non-Profit &amp; Associations</h4></a><h4><a href="/"></a>
<p>Focus on your mission by outsourcing IT.</p>
<a href="/"><h4>Oil and Gas</h4></a></h4><h4><a href="/"></a>
<p>Keep production running with secure, always-on IT.</p>
<a href="/"><h4>Private Equity</h4></a></h4><h4><a href="/"></a>
<p>Accelerate PE client deals and secure data.</p>
        </h4></div>
        <div class="panel-col">
           <a href="/"><h4>Municipality</h4></a><h4><a href="/"></a>
<p>Empower Your Municipality with Secure, Reliable IT Services</p>
<a href="/"><h4>State &amp; Local Government</h4></a></h4><h4><a href="/"></a>
<p>Execute initiatives and develop IT strategies.</p>
        </h4></div>
        <div class="panel-col">
            <img src="/wp-content/themes/upsidenowbasic/assets/images/rackserver.webp" alt="Client Support" style="width:150px;">
            <p>Our support team resolves 95% of tickets within one business day.</p>
        </div>
    </div>

    <!-- Insigts -->
    <div class="dropdown-panel" data-panel="book">
        <div class="panel-col">
            <a href="/"><h4>Blog</h4></a><h4><a href="/"></a>
<p>Get the latest industry insights and trends.</p>
<a href="/"><h4>Webinars &amp; Events</h4></a></h4><h4><a href="/"></a>
<p>Join us at events in person and online. </p>
        </h4></div>
        <div class="panel-col">
         <a href="/"><h4>Video</h4></a><h4><a href="/"></a>
<p>Hear from clients and learn more about strategic IT.</p>
<a href="/"><h4>Success Stories</h4></a></h4><h4><a href="/"></a>
<p>See how Dataprise can make IT your greatest asset.</p>
        </h4></div>
        <div class="panel-col">
        <a href="/"><h4>Whitepapers &amp; Data Sheets</h4></a><h4><a href="/"></a>
<p>Get informative technical resources from IT experts.</p>
<a href="/"><h4>D3: Dataprise Defense Digest</h4></a></h4><h4><a href="/"></a>
<p>Stay on stop of emerging cybersecurity threats.</p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4>Messaging for Your Business</h4></a><h4><a href="/"></a>
<p>Communicate Your Core Value Proposition Clearly, Convincingly, and Consistently</p>
<p>A strong idea told authentically can often do more than a multi-million-dollar media buy. Say what you mean in clear, concise, honest language. If you’re promoting a small business with a limited budget, here is a language playbook.</p>

        </h4></div>
        <div class="panel-col">
            <img src="/wp-content/themes/upsidenowbasic/assets/images/cyberlock.webp" alt="Book a Call" style="width:150px;">
            <p>Most clients leave their first call with a clear, costed plan in hand.</p>
        </div>
    </div>
    <!-- Company -->
    <div class="dropdown-panel" data-panel="company">
        <div class="panel-col">
            <a href="/"><h4>Overview</h4></a><h4><a href="/"></a>
<p>Gain a strategic asset by bringing harmony to IT.</p>
<a href="/"><h4>Our Approach</h4></a></h4><h4><a href="/"></a>
<p>Ensure 24/7 support and security with dedicated teams.</p>
<a href="/"><h4>Partners</h4></a></h4><h4><a href="/"></a>
<p>Drive business forward by partnering with Dataprise.</p>

        </h4></div>
        <div class="panel-col">
   <a href="/"><h4>News &amp; Awards</h4></a><h4><a href="/"></a>
<p>Discover the recognition Dataprise has earned. </p>
<a href="/"><h4>Careers</h4></a></h4><h4><a href="/"></a>
<p>Help us help businesses with strategic IT.</p>
<a href="/"><h4>Mergers and Acquisitions</h4></a></h4><h4><a href="/"></a>
<p>Grow through acquisition and partnership with Dataprise.</p>
        </h4></div>
        <div class="panel-col">
   <a href="/"><h4>Diversity, Equity &amp; Inclusion</h4></a><h4><a href="/"></a>
<p>Embracing different perspectives and backgrounds.</p>
<a href="/"><h4>Locations</h4></a></h4><h4><a href="/"></a>
<p>Find a Dataprise location near you.</p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4>Cloud &amp; Infrastructure</h4></a>
            <p>Improve efficiency, productivity and outcomes with cloud.</p>
            <a href="/"><h4>Cloud &amp; Infrastructure</h4></a>
            <p>Improve efficiency, productivity and outcomes with cloud.</p>
            <a href="/"><h4>Cloud &amp; Infrastructure</h4></a>
            <p>Improve efficiency, productivity and outcomes with cloud.</p>
        </div>
        <div class="panel-col">
            <img src="/wp-content/themes/upsidenowbasic/assets/images/donna.webp" alt="Book a Call" style="width:150px;">
            <p>Most clients leave their first call with a clear, costed plan in hand.</p>
        </div>
    </div>
</div>

<!--------   -----------------------   -------->
<!--------   MOBILE MENU STARTS HERE   -------->
<!--------   -----------------------   -------->
 <nav class="mobile-nav" aria-hidden="true">
    <div class="mobile-item">
        <div class="mobile-item-header">Services <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4>Web Design</h4>
                <a href="/">Portfolio &amp; Showcase Sites</a>
                <a href="/">Landing Page Design</a>
                <a href="/">UI / UX Redesigns</a>
            </div>
            <div class="m-group">
                <h4>Development</h4>
                <a href="/">Custom Web Applications</a>
                <a href="/">CMS &amp; E-Commerce</a>
                <a href="/">API Integrations</a>
            </div>
            <div class="m-group">
                <h4>Digital Marketing</h4>
                <a href="/">Search Engine Optimisation</a>
                <a href="/">Google Ads Management</a>
                <a href="/">Social Media Campaigns</a>
            </div>
            <div class="m-group">
                <h4>Consulting</h4>
                <a href="/">Digital Strategy Sessions</a>
                <a href="/">Technology Audits</a>
                <a href="/">Growth Roadmapping</a>
            </div>
        </div>
    </div>
    <div class="mobile-item">
        <div class="mobile-item-header">Client Support <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4>Getting Started</h4>
                <a href="/">Onboarding Checklist</a>
                <a href="/">How It Works</a>
                <a href="/">Client Portal Access</a>
            </div>
            <div class="m-group">
                <h4>Account &amp; Billing</h4>
                <a href="/">View Invoices</a>
                <a href="/">Update Payment Method</a>
                <a href="/">Billing FAQs</a>
            </div>
            <div class="m-group">
                <h4>Technical Help</h4>
                <a href="/">Submit a Support Ticket</a>
                <a href="/">Live Chat</a>
                <a href="/">System Status</a>
            </div>
            <div class="m-group">
                <h4>Contact Us</h4>
                <a href="/">Send an Email</a>
                <a href="/">Call Our Office</a>
                <a href="/">Find Us on LinkedIn</a>
            </div>
        </div>
    </div>
    <div class="mobile-item">
        <div class="mobile-item-header">Book a Call <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4>Free Consultation</h4>
                <a href="/">30-Minute Intro Call</a>
                <a href="/">What to Expect</a>
                <a href="/">Check Availability</a>
            </div>
            <div class="m-group">
                <h4>Project Discovery</h4>
                <a href="/">Book a Discovery Session</a>
                <a href="/">Prepare Your Brief</a>
                <a href="/">Sample Questions We Ask</a>
            </div>
            <div class="m-group">
                <h4>Product Demo</h4>
                <a href="/">Request a Demo</a>
                <a href="/">View Demo Topics</a>
                <a href="/">Past Client Showcases</a>
            </div>
            <div class="m-group">
                <h4>Pricing</h4>
                <a href="/">View Pricing Plans</a>
                <a href="/">Custom Quote Request</a>
                <a href="/">Compare Packages</a>
            </div>
        </div>
    </div>
</nav>

 <!-- script for extended menubar -->
<script>
    const menubar  = document.querySelector('.menubar');
    const dropdowns = menubar.querySelectorAll('.dropdown');

    menubar.addEventListener('mouseleave', () => {
        menubar.classList.remove('open');
        delete menubar.dataset.active;
        dropdowns.forEach(d => d.classList.remove('active'));
    });

    dropdowns.forEach(d =>
        d.addEventListener('mouseenter', () => {
            menubar.classList.add('open');
            menubar.dataset.active = d.dataset.panel;
            dropdowns.forEach(other => other.classList.remove('active'));
            d.classList.add('active');
        })
    );
        // Mobile hamburger
    const mobileToggle = document.querySelector('.mobile-toggle');
    const mobileNav    = document.querySelector('.mobile-nav');

    mobileToggle.addEventListener('click', () => {
        const isOpen = mobileNav.classList.toggle('open');
        mobileToggle.classList.toggle('open', isOpen);
        mobileToggle.setAttribute('aria-expanded', isOpen);
        mobileNav.setAttribute('aria-hidden', !isOpen);
    });

    // Mobile accordion
    document.querySelectorAll('.mobile-item-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const wasOpen = item.classList.contains('open');
            document.querySelectorAll('.mobile-item').forEach(i => i.classList.remove('open'));
            if (!wasOpen) item.classList.add('open');
        });
    });
</script>

<script>
(function () {
    var util     = document.getElementById('utilityBar');
    var menuBar  = document.getElementById('menuBar');
    var ann      = document.getElementById('announcementBar');
    var ticking  = false;
    var rafId    = null;

    /* ── Track utility bar top to always align with top of blue bar ── */
    function syncTop() {
        util.style.top = menuBar.getBoundingClientRect().top + 'px';
    }

    /* ── Animate top continuously during the dismiss transition ── */
    function animateDismiss() {
        syncTop();
        // Keep looping for the duration of the CSS transition (400ms)
        rafId = requestAnimationFrame(animateDismiss);
    }
    function stopAnimate() {
        if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
        syncTop(); // final snap
    }

    /* ── Scroll: hide past 100px ── */
    window.addEventListener('scroll', function () {
        if (!ticking) {
            requestAnimationFrame(function () {
                util.classList.toggle('hidden', window.scrollY >= 100);
                ticking = false;
            });
            ticking = true;
        }
    }, { passive: true });

    /* ── Dismiss announcement bar ── */
    document.getElementById('announcementClose').addEventListener('click', function () {
        ann.classList.add('dismissed');
        animateDismiss();
        // Stop the rAF loop once the CSS transition ends
        ann.addEventListener('transitionend', stopAnimate, { once: true });
    });

    // Initial position sync
    document.addEventListener('DOMContentLoaded', syncTop);
    // Fallback if DOMContentLoaded already fired
    syncTop();
})();
</script></div>