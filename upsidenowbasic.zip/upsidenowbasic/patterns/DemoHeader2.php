<?php
/**
 * Title: Demo Header 2
 * Slug: upsidenowbasic/demo-header-2
 * Categories: header
 */
?>
<style>
    body{
        background-color: #0f1923;
        /*font-family: Arial, Helvetica, sans-serif;*/
    }
     .headerbar {
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 9998;
    }
 </style>
 
<!--------------------------------------------
------  DISMISSABLE  ANNOUNCEMENT BAR  -------
--------------------------------------------->
 <style>   
    .announcement {
        position: relative;
        width: 100%;
        display: flex;
        align-items: center;
        background-color: black;
        color:white;
        font-size: small;
        overflow: hidden;
        transition: max-height 0.4s ease, opacity 0.4s ease;
        opacity: 1;
    }
    .announcement p{
        font-size: small;
    }
    .announcement.dismissed {
        max-height: 0;
        opacity: 0;
    }
        .announcement-close {
        position: absolute;
        top: 50%;
        right: 12px;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: white;
        font-size: small;
        line-height: 1;
        cursor: pointer;
        opacity: 0.7;
        padding: 4px 8px;
    }
    .announcement-close:hover { opacity: 1; }
  </style>
<!--------------------------------------------
-----  UTILITY BAR, DISOLVES ON SCROLL  ------
--------------------------------------------->
<style>
    .utilitybar {
        position: fixed;
        display: flex;
        font-size: small;
        align-items: center;
        z-index: 9999;
        width: 100%;
        height: 24px;
        color: white;    
        background-color: #1E3248;
        /* top is set dynamically by JS */
        left: 0;
        opacity: 1;
        transition: transform 0.3s ease, opacity 0.3s ease;
        will-change: transform;
    }
    .utilitybar p {
        margin: 0;
        padding: 0;
    }
    .utilitybar.hidden {
        transform: translateY(-300%);
        opacity: 0;
    }
</style>
<!--------------------  ----------------------
---------------   MAIN MENU   ----------------
----------------------  --------------------->
  <style>  
       .dropdown {
        position: relative;
        cursor: pointer;
    }

    .dropdown > p {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 10px 0;
        padding: 0;
        font-size: medium;
        /*font-weight: 600;*/
        letter-spacing: 0.02em;
        color: rgba(255, 255, 255, 0.85);
        transition: color 0.2s;
        user-select: none;
    }

    .dropdown > p::after {
        content: '';
        display: inline-block;
        width: 7px;
        height: 7px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        transform: rotate(45deg) translateY(-2px);
        transition: transform 0.25s ease;
        flex-shrink: 0;
    }

    .dropdown.active > p {
        color: #B8D0E3;
    }

    .dropdown.active > p::after {
        transform: rotate(-135deg) translateY(-2px);
    }
/* menu bar item without extended dropdown box link only*/
     .no-dropdown {
        position: relative;
        cursor: pointer;
    }

    .no-dropdown > p {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 10px 0;
        padding: 0;
        font-size: medium;
        /*font-weight: 600;*/
        letter-spacing: 0.02em;
        color: rgba(255, 255, 255, 0.85);
        transition: color 0.2s;
        user-select: none;
    }
  .no-dropdown > p:hover {
        color: #ffd300;
    }
  .no-dropdown > p:after {
        color: rgba(255, 255, 255, 0.85);
    }
    .menubar {
        display: grid;
        grid-template-columns: 20% 13% 13% 13% 13% 14% 14%;
        grid-template-rows: 84px auto;
        /*gap: 2%;*/
        width: 100%;
        height: 84px;

        background-image: linear-gradient(to right, rgb(40, 70, 95, 0.95), rgb(15, 25, 35,0.95));
        color: white;
        transition: height 0.3s ease;
        overflow: hidden;
        align-items: end;
    }

    .menubar.open {
        height: 600px;
        border-bottom: 2px solid #4eb5f7;
    }

    /* Expanded content panel — spans full menubar width */
    .dropdown-panel {
        display: none;
        grid-column: 1 / -1;
        padding: 24px 0 32px 0;
        border-top: 1px solid rgba(255, 211, 0, 0.25);
        margin-top: 8px;
    }

    .menubar[data-active="services"] .dropdown-panel[data-panel="services"],
    .menubar[data-active="support"]  .dropdown-panel[data-panel="support"],
    .menubar[data-active="book"]     .dropdown-panel[data-panel="book"],
    .menubar[data-active="company"]     .dropdown-panel[data-panel="company"] {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 24px;
    }

    .panel-col img {
        width: 100%;
        border-radius: 4px;
        display: block;
        margin-bottom: 10px;
        object-fit: cover;
    }

    .panel-col {
        padding: 0 16px;
        border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .panel-col:last-child {
        border-right: none;
    }

    .panel-col h4 {
        font-size: large;
        font-weight: 300;
       
  
        color: #B8D0E3;
        margin: 0 0 12px 0;
    }

    .panel-col p {
        font-size: medium;
        line-height: 1.5;
        color: rgba(255, 255, 255, 0.72);
        margin: 0 0 14px 0;
    }

    .panel-col a {
        display: block;
        font-size: medium;
        color: rgba(255, 255, 255, 0.55);
        text-decoration: none;
        margin-bottom: 8px;
        transition: color 0.15s;
    }

    .panel-col a h4:hover {
        color: #ffd300;
    }
  
    /* ── Hamburger button ── */
    .mobile-toggle {
        display: none;
        flex-direction: column;
        justify-content: center;
        gap: 5px;
        background: none;
        border: none;
        cursor: pointer;
        padding: 8px 16px 8px 8px;
        align-self: center;
        justify-self: end;
    }

    .mobile-toggle span {
        display: block;
        width: 24px;
        height: 2px;
        background: white;
        border-radius: 2px;
        transition: transform 0.25s ease, opacity 0.25s ease;
    }

    .mobile-toggle.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
    .mobile-toggle.open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
    .mobile-toggle.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

    /* ── Mobile nav drawer ── */
    .mobile-nav {
        display: none;
        background: #0f1923;
        border-top: 2px solid #ffd300;
    }

    .mobile-nav.open { display: block; }

    .mobile-item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        color: rgba(255, 255, 255, 0.85);
        font-size: medium;
        font-weight: 600;
        cursor: pointer;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        user-select: none;
        transition: color 0.2s;
    }

    .mobile-item-header .m-arrow {
        width: 8px;
        height: 8px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        transform: rotate(45deg) translateY(-2px);
        transition: transform 0.25s ease;
        flex-shrink: 0;
    }

    .mobile-item.open .mobile-item-header { color: #ffd300; }
    .mobile-item.open .mobile-item-header .m-arrow { transform: rotate(-135deg) translateY(-2px); }

    .mobile-item-panel {
        display: none;
        padding: 16px 20px 20px;
        background: rgba(0, 0, 0, 0.3);
        columns: 2;
        column-gap: 24px;
    }

    .mobile-item.open .mobile-item-panel { display: block; }

    .mobile-item-panel h4 {
        font-size: small;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #ffd300;
        margin: 0 0 8px;
        break-after: avoid;
    }

    .mobile-item-panel a {
        display: block;
        font-size: small;
        color: rgba(255, 255, 255, 0.6);
        text-decoration: none;
        padding: 4px 0;
        transition: color 0.15s;
    }

    .mobile-item-panel a:hover { color: #ffd300; }

    .mobile-item-panel .m-group { break-inside: avoid; margin-bottom: 16px; }

    /* ── Breakpoint ── */
    @media (max-width: 850px) {
        .menubar {
            grid-template-columns: 1fr auto;
            grid-template-rows: 60px;
            height: 60px !important;
            border-bottom: none !important;
        }

        .menubar > .dropdown,
        .menubar > .dropdown-panel {
            display: none;
        }

        .mobile-toggle { display: flex; }
        .announcement p{
            font-size: x-small;
        }
    }
</style>    


 <div class="headerbar">
    <div class="announcement" id="announcementBar">
        <button class="announcement-close" id="announcementClose" aria-label="<?php esc_attr_e( 'Dismiss', 'upsidenowbasic' ); ?>">✕</button>
        <p>&nbsp; &nbsp;<?php esc_html_e( 'Free Assessment & Consultation for San Jose SMBs - Limited Spots Available.', 'upsidenowbasic' ); ?>  <a href="#" style="color:#ffd300;"><?php esc_html_e( 'Claim yours->', 'upsidenowbasic' ); ?></a></p>
    </div>
<div class="utilitybar" id="utilityBar" style="top: 48px;">
    <p>&nbsp; &nbsp; <?php esc_html_e( 'Need help setting up your website? Give me a call.', 'upsidenowbasic' ); ?> &nbsp; &nbsp;<img src="/wp-content/themes/upsidenowbasic/assets/images/phone-1.webp" alt="<?php esc_attr_e( 'Book a Call', 'upsidenowbasic' ); ?>" style="width:16px;"> <a href="tel:+14085550100" style="text-decoration:none;">(408) 479-4274</a>
                &nbsp;|&nbsp; <?php esc_html_e( 'San Jose, CA', 'upsidenowbasic' ); ?></p>
</div>
    
<div class="menubar" id="menuBar">
    <div><img src="/wp-content/themes/upsidenowbasic/assets/images/templogo.webp" alt="" style="height: 30px"></div>
    <button class="mobile-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'upsidenowbasic' ); ?>" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>

    <div class="dropdown" data-panel="services">
        <p><?php esc_html_e( 'Services', 'upsidenowbasic' ); ?></p>
    </div>

    <div class="dropdown" data-panel="support">
        <p><?php esc_html_e( 'Industries', 'upsidenowbasic' ); ?></p>
    </div>

    <div class="dropdown" data-panel="book">
        <p><?php esc_html_e( 'Insights', 'upsidenowbasic' ); ?></p>
    </div>

    <div class="dropdown" data-panel="company">
        <p><?php esc_html_e( 'Company', 'upsidenowbasic' ); ?></p>
    </div>

    <a href="/"><div class="no-dropdown"><p><?php esc_html_e( 'Client Support', 'upsidenowbasic' ); ?></p></div></a>
    <a href="/"><div class="no-dropdown"><p><?php esc_html_e( 'Book a Free Discovery Call', 'upsidenowbasic' ); ?></p></div></a>

    <!-- Services panel -->
    <div class="dropdown-panel" data-panel="services">
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Complete IT Management', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Let us handle IT so you can focus on growing your business.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Co-Managed IT Services', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Full-stack development from simple integrations to complex web applications and APIs.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Managed End-User Support', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Get multichannel 24/7/365 expert end-user support.', 'upsidenowbasic' ); ?></p>
        </div>
        <div class="panel-col">
           <a href="/"><h4><?php esc_html_e( 'Cybersecurity Services', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Protect, detect, and respond—we keep your business secure.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Disaster Recovery', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Maximize uptime with with industry-leading DRaaS.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Incident Response', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Swiftly mitigate cyber threats and restore security', 'upsidenowbasic' ); ?></p>
        </div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Cloud & Infrastructure', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Improve efficiency, productivity and outcomes with cloud.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Mobility Management', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Ensure all mobile devices, everywhere, are secure.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'IT Consulting', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Gain a competitive edge with strategic IT solutions.', 'upsidenowbasic' ); ?></p>
         </div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'AI-driven Cyber-hygene Program', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Strategic AI guidance to align with your business goals and budget. What could go wrong?', 'upsidenowbasic' ); ?></p>
        </div>
        <div class="panel-col">
            <p><?php esc_html_e( 'Award-winning design and development delivered on time, every time.', 'upsidenowbasic' ); ?></p>
        </div>
    </div>

    <!-- Industries panel -->
    <div class="dropdown-panel" data-panel="support">
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Industries Overview', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'IT for businesses of all sizes, in any industry.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Banking', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Empower institution growth with custom IT solutions.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Financial Services', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Ensure your firm is always in compliance.', 'upsidenowbasic' ); ?> </p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Healthcare', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Improve patient care and staff morale.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Legal', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Deal with pressing legal matters, not IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Media & Entertainment', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Keep up with the evolving digital landscape.', 'upsidenowbasic' ); ?> </p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Non-Profit & Associations', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Focus on your mission by outsourcing IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Oil and Gas', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Keep production running with secure, always-on IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Private Equity', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Accelerate PE client deals and secure data.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
           <a href="/"><h4><?php esc_html_e( 'Municipality', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Empower Your Municipality with Secure, Reliable IT Services', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'State & Local Government', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Execute initiatives and develop IT strategies.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
            <p><?php esc_html_e( 'Our support team resolves 95% of tickets within one business day.', 'upsidenowbasic' ); ?></p>
        </div>
    </div>

    <!-- Insigts -->
    <div class="dropdown-panel" data-panel="book">
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Blog', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Get the latest industry insights and trends.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Webinars & Events', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Join us at events in person and online.', 'upsidenowbasic' ); ?> </p>
        </h4></div>
        <div class="panel-col">
         <a href="/"><h4><?php esc_html_e( 'Video', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Hear from clients and learn more about strategic IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Success Stories', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'See how we can make IT your greatest asset.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
        <a href="/"><h4><?php esc_html_e( 'Whitepapers & Data Sheets', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Get informative technical resources from IT experts.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Defense Digest', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Stay on stop of emerging cybersecurity threats.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Messaging for Your Business', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Communicate Your Core Value Proposition Clearly, Convincingly, and Consistently', 'upsidenowbasic' ); ?></p>
<p><?php esc_html_e( 'A strong idea told authentically can often do more than a multi-million-dollar media buy. Say what you mean in clear, concise, honest language. If you’re promoting a small business with a limited budget, here is a language playbook.', 'upsidenowbasic' ); ?></p>

        </h4></div>
        <div class="panel-col">
            <p><?php esc_html_e( 'Most clients leave their first call with a clear, costed plan in hand.', 'upsidenowbasic' ); ?></p>
        </div>
    </div>
    <!-- Company -->
    <div class="dropdown-panel" data-panel="company">
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Overview', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Gain a strategic asset by bringing harmony to IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Our Approach', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Ensure 24/7 support and security with dedicated teams.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Partners', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Drive business forward by partnering with us.', 'upsidenowbasic' ); ?></p>

        </h4></div>
        <div class="panel-col">
   <a href="/"><h4><?php esc_html_e( 'News & Awards', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Discover the recognition we\'ve earned.', 'upsidenowbasic' ); ?> </p>
<a href="/"><h4><?php esc_html_e( 'Careers', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Help us help businesses with strategic IT.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Mergers and Acquisitions', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Grow through acquisition and partnership with us.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
   <a href="/"><h4><?php esc_html_e( 'Diversity, Equity & Inclusion', 'upsidenowbasic' ); ?></h4></a><h4><a href="/"></a>
<p><?php esc_html_e( 'Embracing different perspectives and backgrounds.', 'upsidenowbasic' ); ?></p>
<a href="/"><h4><?php esc_html_e( 'Locations', 'upsidenowbasic' ); ?></h4></a></h4><h4><a href="/"></a>
<p><?php esc_html_e( 'Find a location near you.', 'upsidenowbasic' ); ?></p>
        </h4></div>
        <div class="panel-col">
            <a href="/"><h4><?php esc_html_e( 'Cloud & Infrastructure', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Improve efficiency, productivity and outcomes with cloud.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Cloud & Infrastructure', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Improve efficiency, productivity and outcomes with cloud.', 'upsidenowbasic' ); ?></p>
            <a href="/"><h4><?php esc_html_e( 'Cloud & Infrastructure', 'upsidenowbasic' ); ?></h4></a>
            <p><?php esc_html_e( 'Improve efficiency, productivity and outcomes with cloud.', 'upsidenowbasic' ); ?></p>
        </div>
        <div class="panel-col">
            <p><?php esc_html_e( 'Most clients leave their first call with a clear, costed plan in hand.', 'upsidenowbasic' ); ?></p>
        </div>
    </div>
</div>

<!--------   -----------------------   -------->
<!--------   MOBILE MENU STARTS HERE   -------->
<!--------   -----------------------   -------->
 <nav class="mobile-nav" aria-hidden="true">
    <div class="mobile-item">
        <div class="mobile-item-header"><?php esc_html_e( 'Services', 'upsidenowbasic' ); ?> <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4><?php esc_html_e( 'Web Design', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Portfolio & Showcase Sites', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Landing Page Design', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'UI / UX Redesigns', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Development', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Custom Web Applications', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'CMS & E-Commerce', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'API Integrations', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Digital Marketing', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Search Engine Optimisation', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Online Ads Management', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Social Media Campaigns', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Consulting', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Digital Strategy Sessions', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Technology Audits', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Growth Roadmapping', 'upsidenowbasic' ); ?></a>
            </div>
        </div>
    </div>
    <div class="mobile-item">
        <div class="mobile-item-header"><?php esc_html_e( 'Client Support', 'upsidenowbasic' ); ?> <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4><?php esc_html_e( 'Getting Started', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Onboarding Checklist', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'How It Works', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Client Portal Access', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Account & Billing', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'View Invoices', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Update Payment Method', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Billing FAQs', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Technical Help', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Submit a Support Ticket', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Live Chat', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'System Status', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Contact Us', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Send an Email', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Call Our Office', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Find Us on LinkedIn', 'upsidenowbasic' ); ?></a>
            </div>
        </div>
    </div>
    <div class="mobile-item">
        <div class="mobile-item-header"><?php esc_html_e( 'Book a Call', 'upsidenowbasic' ); ?> <span class="m-arrow"></span></div>
        <div class="mobile-item-panel">
            <div class="m-group">
                <h4><?php esc_html_e( 'Free Consultation', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( '30-Minute Intro Call', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'What to Expect', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Check Availability', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Project Discovery', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Book a Discovery Session', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Prepare Your Brief', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Sample Questions We Ask', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Product Demo', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'Request a Demo', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'View Demo Topics', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Past Client Showcases', 'upsidenowbasic' ); ?></a>
            </div>
            <div class="m-group">
                <h4><?php esc_html_e( 'Pricing', 'upsidenowbasic' ); ?></h4>
                <a href="/"><?php esc_html_e( 'View Pricing Plans', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Custom Quote Request', 'upsidenowbasic' ); ?></a>
                <a href="/"><?php esc_html_e( 'Compare Packages', 'upsidenowbasic' ); ?></a>
            </div>
        </div>
    </div>
</nav>

 <!-- script for extended menubar -->
<script>
    const menubar  = document.querySelector('.menubar');
    const dropdowns = menubar.querySelectorAll('.dropdown');

    menubar.addEventListener('mouseleave', () => {
        menubar.classList.remove('open');
        delete menubar.dataset.active;
        dropdowns.forEach(d => d.classList.remove('active'));
    });

    dropdowns.forEach(d =>
        d.addEventListener('mouseenter', () => {
            menubar.classList.add('open');
            menubar.dataset.active = d.dataset.panel;
            dropdowns.forEach(other => other.classList.remove('active'));
            d.classList.add('active');
        })
    );
        // Mobile hamburger
    const mobileToggle = document.querySelector('.mobile-toggle');
    const mobileNav    = document.querySelector('.mobile-nav');

    mobileToggle.addEventListener('click', () => {
        const isOpen = mobileNav.classList.toggle('open');
        mobileToggle.classList.toggle('open', isOpen);
        mobileToggle.setAttribute('aria-expanded', isOpen);
        mobileNav.setAttribute('aria-hidden', !isOpen);
    });

    // Mobile accordion
    document.querySelectorAll('.mobile-item-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const wasOpen = item.classList.contains('open');
            document.querySelectorAll('.mobile-item').forEach(i => i.classList.remove('open'));
            if (!wasOpen) item.classList.add('open');
        });
    });
</script>

<script>
(function () {
    var util     = document.getElementById('utilityBar');
    var menuBar  = document.getElementById('menuBar');
    var ann      = document.getElementById('announcementBar');
    var ticking  = false;
    var rafId    = null;

    /* ── Track utility bar top to always align with top of blue bar ── */
    function syncTop() {
        util.style.top = menuBar.getBoundingClientRect().top + 'px';
    }

    /* ── Animate top continuously during the dismiss transition ── */
    function animateDismiss() {
        syncTop();
        // Keep looping for the duration of the CSS transition (400ms)
        rafId = requestAnimationFrame(animateDismiss);
    }
    function stopAnimate() {
        if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
        syncTop(); // final snap
    }

    /* ── Scroll: hide past 100px ── */
    window.addEventListener('scroll', function () {
        if (!ticking) {
            requestAnimationFrame(function () {
                util.classList.toggle('hidden', window.scrollY >= 100);
                ticking = false;
            });
            ticking = true;
        }
    }, { passive: true });

    /* ── Dismiss announcement bar ── */
    document.getElementById('announcementClose').addEventListener('click', function () {
        ann.classList.add('dismissed');
        animateDismiss();
        // Stop the rAF loop once the CSS transition ends
        ann.addEventListener('transitionend', stopAnimate, { once: true });
    });

    // Initial position sync
    document.addEventListener('DOMContentLoaded', syncTop);
    // Fallback if DOMContentLoaded already fired
    syncTop();
})();
</script></div>