<?php
/**
 * Title: Footer (main)
 * Slug: upsidenowbasic/part-footer-main
 * Inserter: no
 *
 * Content for parts/footer-main.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:group {"backgroundColor":"custom-color-1","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-color-1-background-color has-background"><!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:image {"width":"244px","height":"auto","aspectRatio":"3.6365191959043104","sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/templogo.webp" alt="" style="aspect-ratio:3.6365191959043104;width:244px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"width":"42px","height":"auto","sizeSlug":"large","linkDestination":"custom","align":"right"} -->
<figure class="wp-block-image alignright size-large is-resized"><a href="#" target="_blank" rel=" noopener"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/LinkedIn2.webp" alt="" style="width:42px;height:auto"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"lightbox":{"enabled":false},"width":"46px","height":"auto","sizeSlug":"large","linkDestination":"custom","align":"left"} -->
<figure class="wp-block-image alignleft size-large is-resized"><a href="#" target="_blank" rel=" noopener"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/youtube.webp" alt="" style="width:46px;height:auto"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e( 'Your Company Name', 'upsidenowbasic' ); ?><br><?php esc_html_e( '1234 Main Street', 'upsidenowbasic' ); ?><br><?php esc_html_e( 'Anytown, ST 00000', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e( 'Additional info:', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color"><?php esc_html_e( 'contact@example.com', 'upsidenowbasic' ); ?><br><?php esc_html_e( '(408) 555-0100', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:navigation {"ref":4,"textColor":"white","overlayTextColor":"custom-color-1","style":{"spacing":{"blockGap":"var:preset|spacing|50"}}} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"30px"} -->
<div style="height:30px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light"}}}},"textColor":"light","fontSize":"small"} -->
<p class="has-light-color has-text-color has-link-color has-small-font-size"><?php esc_html_e( 'THEME:', 'upsidenowbasic' ); ?> <a href="https://upside-now.com/upsidenowbasic/"><?php esc_html_e( 'UpsideNowBasic', 'upsidenowbasic' ); ?></a> <?php esc_html_e( 'by John MacInnis', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->