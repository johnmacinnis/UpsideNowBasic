<?php
/**
 * Title: Parallax 2
 * Slug: upsidenowbasic/parallax-2
 * Categories: featured
 */
?>
  
  <div class="kittylax">
    <div class="g-view">
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '43.4%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of all websites on the internet run on WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '61.7%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of websites using a known content management system, use WordPress.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '91%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of vulnerabilities reside in plugins.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '20–40%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'higher salaries for AI-specialized WordPress developers in 2025.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><?php esc_html_e( 'Small businesses with a formal marketing plan are', 'upsidenowbasic' ); ?><br><span style="font-size: 36px;"><?php esc_html_e( '6.7x', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'more likely to report marketing success.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '84%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of consumers view a business website as more credible than social media alone.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '94%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of first impressions are design-related.', 'upsidenowbasic' ); ?></p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;"><?php esc_html_e( '31%', 'upsidenowbasic' ); ?></span><br><?php esc_html_e( 'of U.S. shoppers reported not doing business with a small company because it lacked a website.', 'upsidenowbasic' ); ?></p></div>
    </div>
</div> 

