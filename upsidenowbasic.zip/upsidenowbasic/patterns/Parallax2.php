<?php
/**
 * Title: Parallax 2
 * Slug: upsidenowbasic/parallax-2
 * Categories: featured
 */
?>
<style>
  .kittylax {
  background-image: url('/wp-content/themes/upsidenowbasic/assets/images/world-map-kitty.webp'); 
  height: 720px; 
  justify-content: center;
  align-items: center;
  padding-top: 6px;
    /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
}
  .g-view {
    width: 100%;
    height: 700px;
    display: grid;
    grid-template-columns: 48% 48%;
    gap: 2%;
    padding-top: 21px;
    padding-bottom: 75px;
  }
  .scrollblock {
     height: 200px;
     border: 0.5mm solid #395979;
     box-shadow: #395979 0px 50px 100px -20px, #395979 0px 30px 60px -30px,#395979 0px -2px 6px 0px inset;
padding-left: 12px;
padding-right: 12px;
     color: white;
     justify-self:center;
      }

      @keyframes appear {
        from {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
        }
        to {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }

      /* ── Native: Chrome / Edge / Safari 18+ ── */
      @supports (animation-timeline: view()) {
        .scrollblock {
          animation: appear linear;
          animation-timeline: view();
          animation-range: entry 0% cover 40%;
        }
      }

      /* ── Fallback: Firefox ── */
      @supports not (animation-timeline: view()) {
        .scrollblock {
          opacity: 0;
          clip-path: inset(100% 100% 0 0);
          transition: opacity 0.5s linear, clip-path 0.5s linear;
        }
        .scrollblock.in-view {
          opacity: 1;
          clip-path: inset(0 0 0 0);
        }
      }  
   @media only screen and (max-width: 1000px) {
      .g-view {
        grid-template-columns: 100%;
        padding-top: 0;
        padding-bottom: 250px;
      }
    }
  </style>
  
  <div class="kittylax">
    <div class="g-view">
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">43.4%</span><br>of all websites on the internet run on WordPress.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">61.7%</span><br>of websites using a known content management system, use WordPress.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">91%</span><br>of vulnerabilities reside in plugins.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">20–40%</span><br>higher saleries for AI-specialized WordPress developers in 2025.</p></div>
      <div class="scrollblock in-view"><p>Small businesses with a formal marketing plan are<br><span style="font-size: 36px;">6.7x</span><br>more likely to report marketing success.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">84%</span><br>of consumers view a business website as more credible than social media alone.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">94%</span><br>of first impressions are design-related.</p></div>
      <div class="scrollblock in-view"><p><span style="font-size: 36px;">31%</span><br>of U.S. shoppers reported not doing business with a small company because it lacked a website.</p></div>
    </div>
</div> 


    <script>
      // Only runs in Firefox
      if (!CSS.supports('animation-timeline: view()')) {
        const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              // Entering viewport — play forward
              entry.target.classList.add('in-view');
            } else {
              // Leaving viewport — remove class so transition plays in reverse
              entry.target.classList.remove('in-view');
            }
          });
        // threshold 0: fires as soon as any pixel enters OR exits viewport
        }, { threshold: 0 });

        document.querySelectorAll('.scrollblock').forEach(el => observer.observe(el));
      }
    </script>