<?php
/**
 * Title: Training banner
 * Slug: upsidenowbasic/part-training-banner
 * Inserter: no
 *
 * Content for parts/training-banner.html. Kept in a pattern so image URLs can use
 * get_template_directory_uri() and the text is translation-ready.
 *
 * @package upsidenowbasic
 */
?>
<!-- wp:group {"className":"training-hero-banner","style":{"css":"    padding:88px 0 56px; background:#0B1B33; color:#fff;\n    background-image:\n      radial-gradient(700px 320px at 85% -10%, rgba(34,211,238,.18), transparent 60%),\n      radial-gradient(600px 300px at 10% 0%, rgba(41,82,227,.28), transparent 60%);"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group training-hero-banner has-custom-css"><!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:html -->
<style>
.eyebrow{font-family:var(--font-mono); font-size:15px; font-weight:600; letter-spacing:.14em; text-transform:uppercase; color:#22D3EE;}

/* Sweeping light beam — kept out of the block's "Additional CSS" attribute because
   that engine (wp_theme_json::process_blocks_custom_css) can't parse @keyframes/@media. */
.training-hero-banner{ position:relative; overflow:hidden; isolation:isolate; }
.training-hero-banner::before{
  content:"";
  position:absolute;
  top:-50%;
  left:-30%;
  width:35%;
  height:200%;
    background:linear-gradient(
      100deg,
      transparent 0%,
      #ffffff00 30%,
      #ffffff06 48%,
      #ffffff11 50%,
      #ffffff06 52%,
      #ffffff00 70%,
      transparent 100%
    );
  transform:rotate(8deg);
  animation:trainingBannerBeamSweep 16s ease-in-out infinite;
  pointer-events:none;
  z-index:-1;
}
@keyframes trainingBannerBeamSweep{
  0%{ left:-30%; }
  45%{ left:100%; }
  100%{ left:120%; }
}
@media (prefers-reduced-motion: reduce){
  .training-hero-banner::before{ animation:none; display:none; }
}
</style>
  <div class="eyebrow"><?php esc_html_e( 'Aliquip ex ea commodo consequat duis aute irure', 'upsidenowbasic' ); ?></div>
<!-- /wp:html -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"65%"} -->
<div class="wp-block-column" style="flex-basis:65%"><!-- wp:heading {"level":1,"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"xx-large"} -->
<h1 class="wp-block-heading alignwide has-white-color has-text-color has-link-color has-xx-large-font-size"><br><?php esc_html_e( 'Dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat.', 'upsidenowbasic' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"37px"} -->
<div style="height:37px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|light-steel"}}}},"textColor":"light-steel","fontSize":"large"} -->
<p class="has-light-steel-color has-text-color has-link-color has-large-font-size"><?php esc_html_e( 'Nulla pariatur lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"15%"} -->
<div class="wp-block-column" style="flex-basis:15%"></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"><!-- wp:html -->
<style>
   .spinbox {
        position: relative;
        top: 0;
left: 0;
    }
    .ring {
        position: relative;
        top: 0;

        animation:wee-spin 20s infinite linear;
    }
      .middle {
        position: absolute;
        top: 0;
left: 0;
    }
@keyframes wee-spin {
    0%{transform:rotate(0deg)}
    100%{transform:rotate(359deg)}}
</style>

<div class="spinbox">
    <img class="ring" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ring_blank.webp" style="width:100%">
    <img class="middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/middle_blank.webp" style="width:100%">
    <img class="middle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/GBM_.webp" style="height:100%">
</div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"78px"} -->
<div style="height:78px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:separator {"className":"is-style-default","backgroundColor":"light-steel"} -->
<hr class="wp-block-separator has-text-color has-light-steel-color has-alpha-channel-opacity has-light-steel-background-color has-background is-style-default"/>
<!-- /wp:separator -->

<!-- wp:spacer {"height":"43px"} -->
<div style="height:43px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:html -->
<div class="hero-cta-row">
<div class="eyebrow"><?php esc_html_e( 'Ex', 'upsidenowbasic' ); ?> </div>
</div>
<!-- /wp:html -->

<!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"textAlign":"center"}},"textColor":"white"} -->
<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color"><?php esc_html_e( 'Ea commodo consequat.', 'upsidenowbasic' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"24px"} -->
<div style="height:24px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"style":{"typography":{"textAlign":"center"},"elements":{"link":{"color":{"text":"var:preset|color|light-steel"}}}},"textColor":"light-steel"} -->
<p class="has-text-align-center has-light-steel-color has-text-color has-link-color"><?php esc_html_e( 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.', 'upsidenowbasic' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"48px"} -->
<div style="height:48px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:html -->
<style>
  .hero-badges{display:flex; gap:10px; justify-content:center; flex-wrap:wrap; margin-bottom:34px;}
  .hero-cta-row{display:flex; gap:14px; justify-content:center; flex-wrap:wrap; margin-bottom:12px;}
  .hero-meta{display:flex; gap:20px; justify-content:center; flex-wrap:wrap; max-width:640px; margin:0 auto;}

  .badge{display:inline-flex; align-items:center; gap:6px; font-family:var(--font-mono); font-size:12px; font-weight:600; letter-spacing:.04em; padding:6px 12px; border-radius:99px;}

  .badge-cyan{background:rgba(34,211,238,.14); color:#8FE9F7; border:1px solid rgba(34,211,238,.35);}
  .badge-cyan.on-light{background:rgba(34,211,238,.12); color:#0E7490;}
  .badge-gold{background:rgba(201,154,61,.14); color:#8A661E; border:1px solid rgba(201,154,61,.4);}
  .badge-success{background:rgba(18,183,106,.12); color:#0B7A48; border:1px solid rgba(18,183,106,.35);}

   .btn{font-family:var(--font-body); font-weight:600; font-size:15px; border-radius:8px; padding:14px 26px; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; text-decoration:none;}
  .btn-primary{background:#2952E3; color:#fff; box-shadow:0 6px 16px rgba(41,82,227,.35); transition:transform .15s ease, box-shadow .15s ease;}
  .btn-primary:hover{transform:translateY(-2px); box-shadow:0 10px 22px rgba(41,82,227,.45);} 
  .btn-outline{background:transparent; border:1.5px solid rgba(255,255,255,.35); color:#fff;}

  .countdown{display:flex; gap:12px;}
  .countdown .box{background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.14); border-radius:10px; padding:12px 0; width:64px; text-align:center;}
  .countdown .num{font-family:var(--font-display); font-size:22px; color:#fff; font-weight:700;}
  .countdown .lbl{font-family:var(--font-mono); font-size:10px; color:var(--signal-cyan); letter-spacing:.06em; margin-top:2px;}

  .seats-wrap{background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.14); border-radius:14px; padding:18px 22px; min-width:260px; text-align:left;}
  .seats-top{display:flex; justify-content:space-between; font-size:13px; color:#AEC0DE; margin-bottom:9px;}
  .seats-top strong{color:#fff;}
  .bar-track{height:9px; border-radius:99px; background:rgba(255,255,255,.12); overflow:hidden;}
  .bar-fill{height:100%; border-radius:99px; background:linear-gradient(90deg, #2952E3, #22D3EE); width:0%; transition:width 1.1s ease;}

</style>




<div class="hero-badges">
      <span class="badge badge-cyan"><?php esc_html_e( 'Eu fugiat', 'upsidenowbasic' ); ?></span>
      <span class="badge badge-cyan"><?php esc_html_e( 'Nulla pariatur', 'upsidenowbasic' ); ?></span>
      <span class="badge badge-success"><?php esc_html_e( 'Lorem ipsum dolor sit', 'upsidenowbasic' ); ?></span>
    </div>

    <div class="hero-cta-row">
      <a href="#pricing" class="btn btn-primary"><?php esc_html_e( 'Amet consectetur adipiscing', 'upsidenowbasic' ); ?></a>
      <a href="#curriculum" class="btn btn-outline"><?php esc_html_e( 'Elit sed do eiusmod', 'upsidenowbasic' ); ?></a>
    </div>

    <div class="hero-meta">
      <div>
        <div class="eyebrow" style="justify-content:flex-start; margin-bottom:10px; font-size:11px;"><?php esc_html_e( 'Tempor incididunt ut labore et', 'upsidenowbasic' ); ?></div>
        <div class="countdown" id="countdown">
          <div class="box"><div class="num" id="cd-w">--</div><div class="lbl"><?php esc_html_e( 'WEEKS', 'upsidenowbasic' ); ?></div></div>
          <div class="box"><div class="num" id="cd-d">--</div><div class="lbl"><?php esc_html_e( 'DAYS', 'upsidenowbasic' ); ?></div></div>
          <div class="box"><div class="num" id="cd-h">--</div><div class="lbl"><?php esc_html_e( 'HRS', 'upsidenowbasic' ); ?></div></div>
          <div class="box"><div class="num" id="cd-m">--</div><div class="lbl"><?php esc_html_e( 'MIN', 'upsidenowbasic' ); ?></div></div>
          <div class="box"><div class="num" id="cd-s">--</div><div class="lbl"><?php esc_html_e( 'SEC', 'upsidenowbasic' ); ?></div></div>
        </div>
      </div>
      <div class="seats-wrap">
        <div class="seats-top"><span><?php esc_html_e( 'Dolore magna', 'upsidenowbasic' ); ?></span><strong><?php esc_html_e( 'Aliqua', 'upsidenowbasic' ); ?></strong></div>
        <div class="bar-track"><div class="bar-fill" id="seatsBar" style="width:25%"></div></div>
      </div></div>

<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->