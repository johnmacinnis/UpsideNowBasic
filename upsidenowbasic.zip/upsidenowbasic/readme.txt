=== UpsideNowBasic ===
Contributors: Upside-Now.com
Requires at least: 6.7
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The UpsideNowBasic theme is built for web designers to create, publish and maintain a clean, professional, high-performance website quickly and inexpensively for their professional services clients. It includes a curated collection of popular color schemes, pre-installed fonts, and formatted templates to jump-start your development process. In addition to being simple to use, it offers infinite flexible design options so your website design can  grow and evolve with your client's business.

== Copyright ==

UpsideNowBasic WordPress Theme, (C) 2026 upside-now.com.
UpsideNowBasic is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Changelog ==
= 3.0 =
* Added copious postings including readme.txt, style.css, frontpage.html and screenshot, indicating this theme is free software and GPL compatible.
* Removed promotional text, and theme features from screenshot.
* Added skip links. 
* Replaced placeholder email with @example.com
* Several minor code changes made based on unit testing. 
= 2.0 =
* Released August 16, 2026
* screenshot.png set to 1200x900px
* removed accessibility-ready and other irrelevant tags from style.css
* updated 'tested up to' to latest WP version (7.0) in style.css and readme.txt
* bundled images, replaced URLs with local path names
= 1.1 =
* Released: August 1, 2026
= 1.0 =
* Released: March 18, 2026




