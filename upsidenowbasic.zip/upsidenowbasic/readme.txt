=== UpsideNowBasic ===
Contributors: Upside-Now.com
Requires at least: 6.7
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The UpsideNowBasic theme is built for web designers to create, publish and maintain a clean, professional, high-performance website quickly and inexpensively for their professional services clients. It includes a curated collection of popular color schemes, pre-installed fonts, and formatted templates to jump-start your development process. In addition to being simple to use, it offers infinite flexible design options so your website design can  grow and evolve with your client's business.

== Copyright ==

UpsideNowBasic WordPress Theme, (C) 2026 upside-now.com.
UpsideNowBasic is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

* Roboto font, Copyright 2011 The Roboto Project Authors, https://github.com/googlefonts/roboto-3-classic, License: SIL Open Font License, 1.1, https://scripts.sil.org/OFL, bundled at assets/fonts/Roboto/
* Work Sans font, Copyright 2019 The Work Sans Project Authors, https://github.com/weiweihuanghuang/Work-Sans, License: SIL Open Font License, 1.1, https://scripts.sil.org/OFL, bundled at assets/fonts/Work_Sans/
* JetBrains Mono font, Copyright 2020 The JetBrains Mono Project Authors, https://github.com/JetBrains/JetBrainsMono, License: SIL Open Font License, 1.1, https://scripts.sil.org/OFL, bundled at assets/fonts/
* All other images and video in assets/images/ and assets/video/, including the assets/images/GBM.webp and assets/images/GBM_.webp illustrations (created in Adobe Illustrator), are original photography, illustrations, and AI-generated artwork created by the theme author, John MacInnis, and are released under the same license as the theme (GPLv2 or later).

== Changelog ==
= 3.1 =
* Made all user-facing strings in patterns/*.php translation-ready with esc_html_e()/esc_attr_e().
* Removed the stray meta viewport tag from patterns/HeroBannerDemo.php.
* Replaced non-matching upside-now.com links in demo patterns with placeholder links; the only front-facing credit link is now the one in footer-main.html, which matches the Theme URI.
* Removed patterns/LogoBar.php and the third-party company logos it displayed (Cisco, Intel, Philips, HID, Truvantis, SBDC, Score, University of Phoenix, WordPress).
* Rewrote patterns/DemoHeader2.php's mega-menu copy, which had been copied from a real company's website, to generic placeholder copy.
* Added a Resources section crediting bundled fonts (Roboto, Work Sans, JetBrains Mono; all SIL OFL 1.1) and noting that all other images/video are author-created.
* Fixed theme.json font-face declarations for Roboto and Work Sans, which pointed to font files that were missing from the package; the actual font files are now bundled.
* Added missing alt attributes to decorative images in patterns/jspin.php and patterns/TestBanner.php.
* Replaced the author's personal photo (jmac4.webp, jmac7.webp) in patterns/jspin.php and patterns/TestBanner.php with original illustrations (GBM_.webp, GBM.webp) created by the author in Adobe Illustrator.
* Replaced screenshot.png with a genuine 1200x900 screenshot of the theme's actual rendered front page.
* Removed an external third-party script (assets.calendly.com) and a live Calendly widget embed from templates/services-page.html, replacing it with a generic placeholder button.
* Removed an external Google Fonts @import (fonts.googleapis.com) from parts/training-page_bottom.html.
* Removed four third-party stock images (cyberlock.webp, donna.webp, rackserver.webp, shake.webp) sourced from another company's website, used in patterns/DemoHeader2.php.
* Genericized real business-specific content (course/service pricing, cohort dates, personal bio claims, niche/city-specific targeting, a literal "Google Business Profile" mention) across templates/training-page.html, templates/services-page.html, parts/training-banner.html, parts/training-page_bottom.html, parts/services-banner.html, and patterns/FlashCards2.php.
* Removed a broken wp:pattern reference to the deleted upsidenowbasic/logo-bar pattern from templates/services-page.html.
* Removed the YouTube video embed from templates/training-page.html.
* Fixed a broken template-part reference (a non-existent "demo-footer" slug) in templates/search.html and templates/tag.html, which was silently dropping the footer on those pages; both now correctly load footer-main.
* Replaced the author's own hardcoded LinkedIn and YouTube profile links in parts/footer-main.html with placeholder links, matching the rest of that file's placeholder content.
* Removed 7 unused image files from assets/images/, three of which had the real "Upside Now" business name baked into their pixels.
* Cross-checked against the original 2.0 rejection ticket; updated screenshot.png again after the middle7.webp/middle8.webp graphics were genericized.
* Removed templates/demonstration.html, an unused leftover template with no header, footer, or navigation.
* Compressed screenshot.png from ~565KB to ~199KB (lossless) after the WordPress.org Theme Check plugin flagged its file size.
= 3.0 =
* Added copious postings including readme.txt, style.css, frontpage.html and screenshot, indicating this theme is free software and GPL compatible.
* Removed promotional text, and theme features from screenshot.
* Added skip links. 
* Replaced placeholder email with @example.com
* Several minor code changes made based on unit testing. 
= 2.0 =
* Released August 16, 2026
* screenshot.png set to 1200x900px
* removed accessibility-ready and other irrelevant tags from style.css
* updated 'tested up to' to latest WP version (7.0) in style.css and readme.txt
* bundled images, replaced URLs with local path names
= 1.1 =
* Released: August 1, 2026
= 1.0 =
* Released: March 18, 2026




