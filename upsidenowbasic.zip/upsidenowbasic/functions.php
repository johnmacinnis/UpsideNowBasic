<?php
/**
 * upsidenowbasic functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @since upsidenowbasic 1.0
 */

// Adds theme support for post formats.
if ( ! function_exists( 'upsidenowbasic_post_format_setup' ) ) :
	/**
	 * Adds theme support for post formats.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_post_format_setup() {
		add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ), 'align-wide' );
	}
endif;
add_action( 'after_setup_theme', 'upsidenowbasic_post_format_setup' );

// Enqueues editor-style.css in the editors.
if ( ! function_exists( 'upsidenowbasic_editor_style' ) ) :
	/**
	 * Enqueues editor-style.css in the editors.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_editor_style() {
		add_editor_style( 'assets/css/editor-style.css' );
	}
endif;
add_action( 'after_setup_theme', 'upsidenowbasic_editor_style' );

// Enqueues the theme stylesheet on the front.
if ( ! function_exists( 'upsidenowbasic_enqueue_styles' ) ) :
	/**
	 * Enqueues the theme stylesheet on the front.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_enqueue_styles() {
		$suffix = SCRIPT_DEBUG ? '' : '.min';
		$src    = 'style' . $suffix . '.css';

		wp_enqueue_style(
			'upsidenowbasic-style',
			get_parent_theme_file_uri( $src ),
			array(),
			wp_get_theme()->get( 'Version' )
		);
		wp_style_add_data(
			'upsidenowbasic-style',
			'path',
			get_parent_theme_file_path( $src )
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'upsidenowbasic_enqueue_styles' );

// Registers custom block styles.
if ( ! function_exists( 'upsidenowbasic_block_styles' ) ) :
	/**
	 * Registers custom block styles.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_block_styles() {
		register_block_style(
			'core/list',
			array(
				'name'         => 'checkmark-list',
				'label'        => __( 'Checkmark', 'upsidenowbasic' ),
				'inline_style' => '
				ul.is-style-checkmark-list {
					list-style-type: "\2713";
				}

				ul.is-style-checkmark-list li {
					padding-inline-start: 1ch;
				}',
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_block_styles' );

// Registers pattern categories.
if ( ! function_exists( 'upsidenowbasic_pattern_categories' ) ) :
	/**
	 * Registers pattern categories.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_pattern_categories() {

		register_block_pattern_category(
			'upsidenowbasic_page',
			array(
				'label'       => __( 'Pages', 'upsidenowbasic' ),
				'description' => __( 'A collection of full page layouts.', 'upsidenowbasic' ),
			)
		);

		register_block_pattern_category(
			'upsidenowbasic_post-format',
			array(
				'label'       => __( 'Post formats', 'upsidenowbasic' ),
				'description' => __( 'A collection of post format patterns.', 'upsidenowbasic' ),
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_pattern_categories' );

// Registers block binding sources.
if ( ! function_exists( 'upsidenowbasic_register_block_bindings' ) ) :
	/**
	 * Registers the post format block binding source.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_register_block_bindings() {
		register_block_bindings_source(
			'upsidenowbasic/format',
			array(
				'label'              => _x( 'Post format name', 'Label for the block binding placeholder in the editor', 'upsidenowbasic' ),
				'get_value_callback' => 'upsidenowbasic_format_binding',
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_register_block_bindings' );

// Registers block binding callback function for the post format name.
if ( ! function_exists( 'upsidenowbasic_format_binding' ) ) :
	/**
	 * Callback function for the post format name block binding source.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return string|void Post format name, or nothing if the format is 'standard'.
	 */
	function upsidenowbasic_format_binding() {
		$post_format_slug = get_post_format();

		if ( $post_format_slug && 'standard' !== $post_format_slug ) {
			return get_post_format_string( $post_format_slug );
		}
	}
endif;

add_filter( 'register_block_type_args', function( $args, $block_type ) {
	if ( 'core/group' === $block_type && isset( $args['attributes']['align'] ) ) {
		$args['attributes']['align']['default'] = 'wide';
	}
	return $args;
}, 10, 2 );
