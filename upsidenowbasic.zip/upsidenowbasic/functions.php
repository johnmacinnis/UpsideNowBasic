<?php
/**
 * upsidenowbasic functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @since upsidenowbasic 1.0
 */

// Adds theme support for post formats.
if ( ! function_exists( 'upsidenowbasic_post_format_setup' ) ) :
	/**
	 * Adds theme support for post formats.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_post_format_setup() {
		add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ), 'align-wide' );
	}
endif;
add_action( 'after_setup_theme', 'upsidenowbasic_post_format_setup' );

// Enqueues editor-style.css in the editors.
if ( ! function_exists( 'upsidenowbasic_editor_style' ) ) :
	/**
	 * Enqueues editor-style.css in the editors.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_editor_style() {
		add_editor_style( 'assets/css/editor-style.css' );
	}
endif;
add_action( 'after_setup_theme', 'upsidenowbasic_editor_style' );

// Enqueues the theme stylesheet on the front.
if ( ! function_exists( 'upsidenowbasic_enqueue_styles' ) ) :
	/**
	 * Enqueues the theme stylesheet on the front.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_enqueue_styles() {
		$suffix = SCRIPT_DEBUG ? '' : '.min';
		$src    = 'style' . $suffix . '.css';

		wp_enqueue_style(
			'upsidenowbasic-style',
			get_parent_theme_file_uri( $src ),
			array(),
			wp_get_theme()->get( 'Version' )
		);
		wp_style_add_data(
			'upsidenowbasic-style',
			'path',
			get_parent_theme_file_path( $src )
		);

		// Skip-link styles. Normally emitted by WordPress core alongside its
		// auto-injected skip link, which this theme removes (see below), so the
		// custom skip link in templates/front-page.html still needs them.
		wp_add_inline_style(
			'upsidenowbasic-style',
			'.skip-link.screen-reader-text{border:0;clip:rect(1px,1px,1px,1px);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute !important;width:1px;word-wrap:normal !important;}' .
			'.skip-link.screen-reader-text:focus{background-color:#eee;clip:auto !important;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000;}'
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'upsidenowbasic_enqueue_styles' );

// Registers custom block styles.
if ( ! function_exists( 'upsidenowbasic_block_styles' ) ) :
	/**
	 * Registers custom block styles.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_block_styles() {
		register_block_style(
			'core/list',
			array(
				'name'         => 'checkmark-list',
				'label'        => __( 'Checkmark', 'upsidenowbasic' ),
				'inline_style' => '
				ul.is-style-checkmark-list {
					list-style-type: "\2713";
				}

				ul.is-style-checkmark-list li {
					padding-inline-start: 1ch;
				}',
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_block_styles' );

// Registers pattern categories.
if ( ! function_exists( 'upsidenowbasic_pattern_categories' ) ) :
	/**
	 * Registers pattern categories.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_pattern_categories() {

		register_block_pattern_category(
			'upsidenowbasic_page',
			array(
				'label'       => __( 'Pages', 'upsidenowbasic' ),
				'description' => __( 'A collection of full page layouts.', 'upsidenowbasic' ),
			)
		);

		register_block_pattern_category(
			'upsidenowbasic_post-format',
			array(
				'label'       => __( 'Post formats', 'upsidenowbasic' ),
				'description' => __( 'A collection of post format patterns.', 'upsidenowbasic' ),
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_pattern_categories' );

// Registers block binding sources.
if ( ! function_exists( 'upsidenowbasic_register_block_bindings' ) ) :
	/**
	 * Registers the post format block binding source.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_register_block_bindings() {
		register_block_bindings_source(
			'upsidenowbasic/format',
			array(
				'label'              => _x( 'Post format name', 'Label for the block binding placeholder in the editor', 'upsidenowbasic' ),
				'get_value_callback' => 'upsidenowbasic_format_binding',
			)
		);
	}
endif;
add_action( 'init', 'upsidenowbasic_register_block_bindings' );

// Registers block binding callback function for the post format name.
if ( ! function_exists( 'upsidenowbasic_format_binding' ) ) :
	/**
	 * Callback function for the post format name block binding source.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return string|void Post format name, or nothing if the format is 'standard'.
	 */
	function upsidenowbasic_format_binding() {
		$post_format_slug = get_post_format();

		if ( $post_format_slug && 'standard' !== $post_format_slug ) {
			return get_post_format_string( $post_format_slug );
		}
	}
endif;

// Removes the WordPress core auto-injected block template skip link.
// The front page provides its own skip link in templates/front-page.html.
if ( ! function_exists( 'upsidenowbasic_remove_core_skip_link' ) ) :
	/**
	 * Unhooks the core "Skip to content" link for block templates.
	 *
	 * @since upsidenowbasic 1.0
	 *
	 * @return void
	 */
	function upsidenowbasic_remove_core_skip_link() {
		// Unhooking either action makes core skip inserting its skip link
		// (see _block_template_add_skip_link() / wp_enqueue_block_template_skip_link()).
		remove_action( 'wp_footer', 'the_block_template_skip_link' );
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_block_template_skip_link' );
	}
endif;
add_action( 'init', 'upsidenowbasic_remove_core_skip_link' );

add_filter( 'register_block_type_args', function( $args, $block_type ) {
	if ( 'core/group' === $block_type && isset( $args['attributes']['align'] ) ) {
		$args['attributes']['align']['default'] = 'wide';
	}
	return $args;
}, 10, 2 );
